# Brandforge AI

An AI-powered creative platform for early-stage startups. Input your brand description and the system auto-generates a landing page, logo, and marketing strategy in parallel.

**Team:** Tianrui Fang, Hao Chen, Tianyu Zhan  
**Course:** EECS E6895 Advanced Big Data & AI

---

## Stack

- **Backend:** Python 3.11+ · FastAPI · Motor (async MongoDB)
- **Frontend:** React 18 · Vite 5 · Tailwind CSS
- **AI:** OpenAI GPT-4o · DALL-E 3 · FAISS RAG
- **DB:** MongoDB

---

## Local Setup

### Prerequisites

- Python 3.11+
- Node.js 20+
- MongoDB running locally (`mongod`) or a MongoDB Atlas URI

### 1. Clone & configure environment

```bash
cp .env.example .env
# Edit .env — fill in OPENAI_API_KEY and MONGODB_URI at minimum
```

### 2. Backend

```bash
# Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the backend (from repo root)
uvicorn backend.main:app --reload --port 8000
```

API docs available at: http://localhost:8000/docs

### 3. Frontend

```bash
cd frontend
npm install
npm run dev
# → http://localhost:5173
```

---

## Project Structure

```
creative-ai-agent/
├── backend/
│   ├── main.py               # FastAPI app entry
│   ├── config.py             # Pydantic Settings
│   ├── api/                  # REST endpoints (auth, projects, agents)
│   ├── models/               # Pydantic data models
│   ├── agents/
│   │   ├── brand/            # Brand Agent (Tianrui)
│   │   ├── gateway/          # AI Gateway / fan-out (Tianrui)
│   │   ├── marketing/        # Marketing Agent (Hao Chen)
│   │   ├── logo/             # Logo Agent (Hao Chen)
│   │   └── ui_web/           # UI/Web Agent (Tianyu)
│   └── db/                   # MongoDB Motor client
├── frontend/
│   └── src/
│       ├── pages/            # BrandForm, Results
│       ├── components/       # WebPreview, LogoPreview, MarketingView
│       └── api/              # Fetch wrapper
├── data/
│   ├── benchmarks/           # Ad platform benchmark CSVs
│   └── corpus/               # RAG ad-policy corpus (JSONL)
└── tests/
```

---

## API Endpoints

| Endpoint             | Method | Description                        |
| -------------------- | ------ | ---------------------------------- |
| `/api/auth/token`    | POST   | Get JWT token                      |
| `/api/projects`      | POST   | Create project, trigger generation |
| `/api/projects/{id}` | GET    | Poll job status + results          |
| `/api/projects`      | GET    | List user projects                 |
| `/agents/marketing`  | POST   | Marketing Agent (internal)         |
| `/agents/logo`       | POST   | Logo Agent (internal)              |
| `/agents/ui`         | POST   | UI/Web Agent (internal)            |

---

## Task Division

| Member           | Responsibilities                                                                    |
| ---------------- | ----------------------------------------------------------------------------------- |
| **Tianyu Zhan**  | UI/Web Agent · ~~Backend infra · User Profile(to database) · AI Gateway · MongoDB~~ |
| **Hao Chen**     | Marketing Agent (RAG + platform benchmarks) · Logo Agent (SVG + DALL-E 3)           |
| **Tianrui Fang** | React REST · API frontend                                                           |
