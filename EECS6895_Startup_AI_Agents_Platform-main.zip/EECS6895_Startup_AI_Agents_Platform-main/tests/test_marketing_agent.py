"""Smoke tests for the Marketing Agent pipeline with a mocked LLM."""

from __future__ import annotations

import asyncio
import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from backend.agents.marketing.llm.base import BaseLLM
from backend.agents.marketing.agent.router import route_question
from backend.agents.marketing.agent.synthesizer import synthesize_answer
from backend.agents.marketing.tools.registry import run_plan


# ── Fixtures ──────────────────────────────────────────────────────────────────

class MockLLM(BaseLLM):
    """LLM that returns scripted responses for deterministic testing."""

    def __init__(self, responses: list[str]):
        self._responses = iter(responses)

    def generate(self, messages, *, max_new_tokens=256, temperature=0.0, **kwargs) -> str:
        try:
            return next(self._responses)
        except StopIteration:
            return "Default mock response."


ROUTER_PLAN_JSON = json.dumps({
    "plan": [
        {"tool": "platform_chooser", "args": {"industry": "fintech", "region": "US", "include_audience": True}},
        {"tool": "rag", "args": {"question": "Meta ads policy for fintech", "k": 3}},
    ]
})

SYNTHESIS_ANSWER = "Use Meta Ads with $2k/month for fintech. [meta_prohibited_content]"


@pytest.fixture
def mock_llm():
    return MockLLM([ROUTER_PLAN_JSON, SYNTHESIS_ANSWER])


@pytest.fixture
def brand_profile():
    from backend.models.brand_profile import BrandProfile
    return BrandProfile(
        brand_name="TestCo",
        primary_color="#123456",
        accent_color="#abcdef",
        font_family="Inter",
        tone="professional",
        industry="fintech",
        tagline=None,
    )


# ── Router tests ──────────────────────────────────────────────────────────────

def test_route_question_returns_plan(mock_llm):
    plan = route_question("What platforms for fintech ads?", mock_llm)
    assert "plan" in plan
    assert isinstance(plan["plan"], list)
    assert len(plan["plan"]) >= 1


def test_route_question_fallback_on_bad_json():
    bad_llm = MockLLM(["This is not JSON at all"])
    plan = route_question("What platforms for fintech ads?", bad_llm)
    assert "plan" in plan
    assert len(plan["plan"]) > 0  # fallback plan should be non-empty


# ── Tool registry tests ───────────────────────────────────────────────────────

def test_run_plan_unknown_tool():
    plan = {"plan": [{"tool": "nonexistent_tool", "args": {}}]}
    trace = run_plan(plan, tool_registry={})
    assert trace[0]["result"]["error"].startswith("unknown tool")


def test_run_plan_calls_tool():
    def fake_tool(x: int = 0):
        return {"value": x * 2}

    plan = {"plan": [{"tool": "fake", "args": {"x": 5}}]}
    trace = run_plan(plan, tool_registry={"fake": fake_tool})
    assert trace[0]["result"] == {"value": 10}


# ── Platform chooser smoke test ───────────────────────────────────────────────

def test_platform_chooser_returns_structure():
    from backend.agents.marketing.tools.platform_chooser import platform_chooser
    result = platform_chooser(industry="fintech", region="US")
    assert result["status"] == "ok"
    assert "platforms" in result
    assert "audience" in result


# ── Synthesizer tests ─────────────────────────────────────────────────────────

def test_synthesize_answer_includes_citation():
    llm = MockLLM(["Here is the answer without any citation."])
    trace = [
        {
            "tool": "rag",
            "args": {"question": "test"},
            "result": {
                "answer": "test answer",
                "evidence": [{"doc_id": "meta_prohibited_content", "title": "Meta Policy", "var": "", "text": "..."}],
            },
            "result_preview": "...",
        }
    ]
    answer = synthesize_answer("test question", trace, llm)
    # Should append citation if answer had none
    assert "meta_prohibited_content" in answer


# ── Async run_agent smoke test ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_run_agent_e2e(brand_profile):
    """Full pipeline smoke test with mocked LLM and no retriever."""
    from backend.agents.marketing.agent.run import run_agent
    from backend.agents.marketing.llm.base import BaseLLM

    scripted = MockLLM([ROUTER_PLAN_JSON, SYNTHESIS_ANSWER])

    # Pass retriever=None to skip FAISS build; platform_chooser tool still runs
    result = await run_agent(
        question="What ad platforms should I use for my fintech app?",
        llm=scripted,
        retriever=None,
        brand_profile=brand_profile,
    )

    assert "final_answer" in result
    assert "plan" in result
    assert "trace" in result
    assert len(result["trace"]) >= 1
