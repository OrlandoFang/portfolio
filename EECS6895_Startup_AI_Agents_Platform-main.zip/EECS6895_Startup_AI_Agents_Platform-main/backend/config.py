"""Application configuration loaded from environment / .env file."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=Path(__file__).resolve().parent.parent / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        **kwargs: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        # .env file takes precedence over shell environment variables
        return (init_settings, dotenv_settings, env_settings, *kwargs.values())

    # OpenAI
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"
    openai_base_url: str = "https://api.openai.com/v1"

    # MongoDB
    mongodb_uri: str = "mongodb://localhost:27017"
    mongodb_db: str = "brandforge"

    # Auth
    jwt_secret: str = "change_me_in_production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 1440

    # DALL-E (image generation) — separate endpoint from chat completions
    # Falls back to openai_api_key / openai_base_url if left empty
    dalle_api_key: str = ""
    dalle_base_url: str = ""
    dalle_model: str = "dall-e-3"

    # RAG
    corpus_path: str = "data/corpus/ad_policy_corpus.jsonl"
    embed_model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    rag_top_k: int = 3

    # Server
    backend_port: int = 8000
    frontend_origin: str = "http://localhost:5173"

    @property
    def corpus_abs_path(self) -> Path:
        p = Path(self.corpus_path)
        if not p.is_absolute():
            return Path(__file__).resolve().parent.parent / p
        return p

    @property
    def benchmarks_dir(self) -> Path:
        return Path(__file__).resolve().parent.parent / "data" / "benchmarks"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
