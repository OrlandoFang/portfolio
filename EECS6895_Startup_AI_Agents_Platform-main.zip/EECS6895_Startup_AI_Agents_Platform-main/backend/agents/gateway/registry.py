"""Registry of downstream agents the gateway can fan out to.

This module is the single integration point teammates' agents plug into.
Keep adapters here thin — the real implementations live in each teammate's
package (``backend/agents/{logo,marketing,ui_web}``).
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from backend.models.brand_profile import BrandProfile

# Each adapter must be an async callable: (BrandProfile) -> dict
AgentAdapter = Callable[[BrandProfile], Awaitable[dict[str, Any]]]


# ── Adapters ───────────────────────────────────────────────────────────────
async def _run_marketing(brand_profile: BrandProfile) -> dict[str, Any]:
    """Hao Chen — Marketing Agent."""
    from backend.agents.marketing.agent.run import run_agent

    result = await run_agent(
        question=(
            f"Create an ad strategy for {brand_profile.brand_name} "
            f"in the {brand_profile.industry} industry with a {brand_profile.tone} tone."
        ),
        brand_profile=brand_profile,
    )
    trace = result.get("trace", [])
    platform_recs: dict[str, Any] = {}
    for t in trace:
        if t.get("tool") == "platform_chooser" and isinstance(t.get("result"), dict):
            r = t["result"]
            platform_recs = {
                "platforms": r.get("platforms", []),
                "audience": r.get("audience", []),
                "region": r.get("region", ""),
                "industry_query": r.get("industry_query", ""),
            }
            break
    return {
        "strategy": result.get("final_answer", ""),
        "platform_recommendations": platform_recs,
        "trace": trace,
    }


async def _run_logo(
    brand_profile: BrandProfile,
    style: str = "minimal",
    theme_colors: list[str] | None = None,
) -> dict[str, Any]:
    """Hao Chen — Logo Agent."""
    from backend.agents.logo.generator import generate_logo

    return await generate_logo(brand_profile, style=style, theme_colors=theme_colors)


async def _run_website(
    brand_profile: BrandProfile,
    style: str = "minimal",
    theme_colors: list[str] | None = None,
) -> dict[str, Any]:
    """Tianyu Zhan — UI / Web Agent."""
    from backend.agents.ui_web.ui_agent import generate_website

    return await generate_website(
        brand_profile,
        style=style,
        theme_colors=theme_colors,
    )


# ── Registry ───────────────────────────────────────────────────────────────
AGENT_REGISTRY: dict[str, AgentAdapter] = {
    "marketing": _run_marketing,
    "logo": _run_logo,
    "website": _run_website,
}


def get_agent(name: str) -> AgentAdapter | None:
    return AGENT_REGISTRY.get(name)
