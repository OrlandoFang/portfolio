"""AI Gateway — fan out BrandProfile requests to downstream agents.

Responsibilities:
- Accept a ``BrandProfile`` and a list of requested output types.
- Dispatch the matching agents concurrently with ``asyncio.gather``.
- Tolerate partial failure: if one agent raises, the rest still finish and we
  record the error on that agent's ``AgentResult``.
- Persist per-agent status/output to MongoDB (``jobs`` + ``projects``
  collections) so the REST API can poll progress.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any

from backend.agents.gateway.registry import AGENT_REGISTRY, get_agent
from backend.db import jobs_collection, projects_collection
from backend.models.brand_profile import BrandProfile
from backend.models.job import GenerationJob
from backend.models.project import AgentResult

logger = logging.getLogger(__name__)


# ── Public API ─────────────────────────────────────────────────────────────
async def dispatch(
    brand_profile: BrandProfile,
    outputs: list[str],
    *,
    project_id: str | None = None,
    persist: bool = False,
    style: str = "minimal",
    theme_colors: list[str] | None = None,
) -> dict[str, AgentResult]:
    """Dispatch the requested agents in parallel.

    Args:
        brand_profile: Extracted brand identity to pass to every agent.
        outputs: Requested output names — only those present in
            :data:`backend.agents.gateway.registry.AGENT_REGISTRY` are run;
            unknown values are skipped with an ``error`` result.
        project_id: If provided, per-agent status is persisted to MongoDB so
            the frontend can poll ``GET /api/projects/{id}`` during generation.
        persist: Set to ``True`` along with ``project_id`` to write job rows
            and patch the project document.
        style: Style preference forwarded to agents that use it (e.g. logo).

    Returns:
        Dict mapping each requested output name to an :class:`AgentResult`.
    """
    results: dict[str, AgentResult] = {}
    coros: list[asyncio.Task] = []
    names: list[str] = []

    for name in outputs:
        adapter = get_agent(name)
        if adapter is None:
            logger.warning("Unknown output requested: %s", name)
            results[name] = AgentResult(status="error", error=f"Unknown output type: {name}")
            if persist and project_id:
                await _upsert_job(project_id, name, status="error", error=results[name].error)
            continue
        if persist and project_id:
            await _upsert_job(project_id, name, status="running")
        names.append(name)
        coros.append(
            asyncio.create_task(
                _safe_run(name, adapter, brand_profile, style=style, theme_colors=theme_colors)
            )
        )

    if coros:
        settled = await asyncio.gather(*coros)
        for name, agent_result in zip(names, settled):
            results[name] = agent_result
            if persist and project_id:
                await _upsert_job(
                    project_id,
                    name,
                    status=agent_result.status,
                    output=agent_result.output,
                    error=agent_result.error,
                )

    if persist and project_id:
        await _patch_project_results(project_id, results)

    return results


# ── Internal helpers ──────────────────────────────────────────────────────
async def _safe_run(
    name: str,
    adapter,
    brand_profile: BrandProfile,
    style: str = "minimal",
    theme_colors: list[str] | None = None,
) -> AgentResult:
    """Run an adapter, capturing any exception as an error AgentResult."""
    try:
        output = (
            await adapter(brand_profile, style=style, theme_colors=theme_colors)
            if name in ("logo", "website")
            else await adapter(brand_profile)
        )
        if not isinstance(output, dict):
            output = {"value": output}
        return AgentResult(status="done", output=output)
    except NotImplementedError as exc:
        logger.info("Agent '%s' not implemented yet: %s", name, exc)
        return AgentResult(status="error", error=f"{name} not implemented: {exc}")
    except Exception as exc:  # noqa: BLE001
        logger.exception("Agent '%s' failed", name)
        return AgentResult(status="error", error=str(exc))


async def _upsert_job(
    project_id: str,
    agent_type: str,
    *,
    status: str,
    output: dict[str, Any] | None = None,
    error: str | None = None,
) -> None:
    """Insert or update a row in the ``jobs`` collection."""
    try:
        job = GenerationJob(
            project_id=project_id,
            agent_type=agent_type,
            status=status,  # type: ignore[arg-type]
            output=output,
            error=error,
            updated_at=datetime.utcnow(),
        )
        await jobs_collection().update_one(
            {"project_id": project_id, "agent_type": agent_type},
            {
                "$set": {
                    "status": job.status,
                    "output": job.output,
                    "error": job.error,
                    "updated_at": job.updated_at.isoformat(),
                },
                "$setOnInsert": {
                    "project_id": project_id,
                    "agent_type": agent_type,
                    "created_at": job.created_at.isoformat(),
                },
            },
            upsert=True,
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("jobs upsert failed for %s/%s: %s", project_id, agent_type, exc)


async def _patch_project_results(project_id: str, results: dict[str, AgentResult]) -> None:
    """Merge per-agent results into the project document (convenience fields)."""
    try:
        logo = (results.get("logo").output or {}) if results.get("logo") else {}
        marketing = (results.get("marketing").output or {}) if results.get("marketing") else {}
        website = (results.get("website").output or {}) if results.get("website") else {}

        overall_status = "done" if all(r.status == "done" for r in results.values()) else (
            "error" if all(r.status == "error" for r in results.values()) else "done"
        )

        await projects_collection().update_one(
            {"_id": project_id},
            {
                "$set": {
                    "results": {k: v.model_dump() for k, v in results.items()},
                    "logo_svg": logo.get("svg"),
                    "logo_image_url": logo.get("image_url"),
                    "marketing_strategy": marketing.get("strategy"),
                    "platform_recommendations": marketing.get("platform_recommendations") or None,
                    "website_html": website.get("html"),
                    "status": overall_status,
                    "updated_at": datetime.utcnow().isoformat(),
                }
            },
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to patch project %s with gateway results: %s", project_id, exc)


# Keep the registry importable from the package root for teammates.
__all__ = ["dispatch", "AGENT_REGISTRY"]
