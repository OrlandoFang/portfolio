"""FastAPI router for the Logo Agent endpoint."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.models.brand_profile import BrandProfile

router = APIRouter()


class LogoRequest(BaseModel):
    brand_profile: BrandProfile
    style: str = "minimal"  # minimal | bold | playful | corporate
    mode: Literal["svg", "dalle", "both"] = "both"


class LogoResponse(BaseModel):
    svg: str
    image_url: str | None = None


@router.post("/agents/logo", response_model=LogoResponse)
async def logo_endpoint(req: LogoRequest) -> LogoResponse:
    """Generate SVG and/or DALL-E 3 logo for a brand.

    - mode="svg"   — LLM-generated SVG only (fast, no images API needed)
    - mode="dalle" — DALL-E 3 image only (requires DALLE_API_KEY in .env)
    - mode="both"  — both in parallel (default)
    """
    try:
        from backend.agents.logo.generator import generate_logo
        result = await generate_logo(req.brand_profile, req.style, req.mode)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Logo agent failed: {e}")

    if req.mode in ("svg", "both") and not result["svg"]:
        raise HTTPException(status_code=500, detail="SVG generation failed: LLM returned empty response")

    return LogoResponse(svg=result["svg"], image_url=result["image_url"])
