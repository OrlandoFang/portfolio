"""Logo Agent — LLM → SVG + DALL-E 3."""
