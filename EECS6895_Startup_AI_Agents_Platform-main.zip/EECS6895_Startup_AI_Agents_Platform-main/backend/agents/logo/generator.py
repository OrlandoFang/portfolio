"""Logo generation: LLM → SVG and DALL-E 3 → image URL."""

from __future__ import annotations

import asyncio
import re
from typing import Any, Literal

from openai import OpenAI

from backend.agents.logo.prompts import (
    build_dalle_user_prompt,
    build_svg_system_prompt,
    build_svg_user_prompt,
)
from backend.config import get_settings
from backend.models.brand_profile import BrandProfile


def _get_client() -> OpenAI:
    s = get_settings()
    return OpenAI(api_key=s.openai_api_key, base_url=s.openai_base_url)


def _get_dalle_client() -> OpenAI:
    """Return OpenAI client configured for DALL-E, falling back to chat settings."""
    s = get_settings()
    return OpenAI(
        api_key=s.dalle_api_key or s.openai_api_key,
        base_url=s.dalle_base_url or s.openai_base_url,
    )


# ── SVG generation ────────────────────────────────────────────────────────────


def _normalise_hex(value: str) -> str:
    """Normalise #RGB/#RRGGBB into uppercase #RRGGBB."""
    v = value.strip()
    if re.fullmatch(r"#[0-9a-fA-F]{3}", v):
        return "#" + "".join(ch * 2 for ch in v[1:]).upper()
    if re.fullmatch(r"#[0-9a-fA-F]{6}", v):
        return v.upper()
    return v


def _build_allowed_palette(brand_profile: BrandProfile, theme_colors: list[str] | None) -> list[str]:
    """Use full selected theme list; fallback to primary/accent when unavailable."""
    seen: set[str] = set()
    normalized: list[str] = []

    for raw in (theme_colors or []):
        c = _normalise_hex(raw)
        if re.fullmatch(r"#[0-9A-F]{6}", c) and c not in seen:
            seen.add(c)
            normalized.append(c)

    if normalized:
        return normalized

    for raw in (brand_profile.primary_color, brand_profile.accent_color):
        c = _normalise_hex(raw)
        if re.fullmatch(r"#[0-9A-F]{6}", c) and c not in seen:
            seen.add(c)
            normalized.append(c)
    return normalized


def _enforce_svg_palette(svg: str, allowed_palette: list[str]) -> str:
    """Hard-lock SVG colours to the allowed palette list."""
    allowed = set(allowed_palette)
    fallback = allowed_palette[0] if allowed_palette else "#000000"

    def _map_colour(token: str) -> str:
        colour = _normalise_hex(token)
        return colour if colour in allowed else fallback

    # Only rewrite explicit colour-bearing attributes.
    attr_re = re.compile(
        r'((?:fill|stroke|stop-color|color)\s*=\s*[\'"])\s*(#[0-9a-fA-F]{3,6})\s*([\'"])',
        flags=re.IGNORECASE,
    )
    svg = attr_re.sub(lambda m: f"{m.group(1)}{_map_colour(m.group(2))}{m.group(3)}", svg)

    # Rewrite inline style declarations for the same properties.
    style_re = re.compile(
        r"((?:fill|stroke|stop-color|color)\s*:\s*)(#[0-9a-fA-F]{3,6})(\s*;?)",
        flags=re.IGNORECASE,
    )
    svg = style_re.sub(lambda m: f"{m.group(1)}{_map_colour(m.group(2))}{m.group(3)}", svg)
    return svg


def _sanitize_svg(svg: str) -> str:
    """Remove script tags and ensure viewBox is present."""
    svg = re.sub(r"<script[^>]*>.*?</script>", "", svg, flags=re.DOTALL | re.IGNORECASE)
    svg = re.sub(r"\son\w+\s*=\s*['\"][^'\"]*['\"]", "", svg, flags=re.IGNORECASE)
    if 'viewBox' not in svg and '<svg' in svg:
        svg = svg.replace("<svg", '<svg viewBox="0 0 200 200"', 1)
    return svg.strip()


def _extract_svg(text: str) -> str:
    """Extract <svg...>...</svg> from LLM response."""
    text = re.sub(r"```[a-zA-Z]*\n?", "", text).strip()
    match = re.search(r"(<svg[\s\S]*?</svg>)", text, re.IGNORECASE)
    if match:
        return _sanitize_svg(match.group(1))
    if "<svg" in text.lower():
        return _sanitize_svg(text)
    return ""


def generate_svg(brand_profile: BrandProfile, style: str, theme_colors: list[str] | None = None) -> str:
    """Call LLM to generate an SVG logo. Returns SVG string or empty string on failure."""
    client = _get_client()
    s = get_settings()
    allowed_palette = _build_allowed_palette(brand_profile, theme_colors)
    try:
        resp = client.chat.completions.create(
            model=s.openai_model,
            messages=[
                {"role": "system", "content": build_svg_system_prompt()},
                {"role": "user", "content": build_svg_user_prompt(brand_profile, style, allowed_palette)},
            ],
            max_tokens=2048,
            temperature=0.45,
        )
        raw = (resp.choices[0].message.content or "").strip()
        svg = _extract_svg(raw)
        return _enforce_svg_palette(svg, allowed_palette) if svg else ""
    except Exception as e:
        print(f"[logo] SVG generation failed: {e}")
        return ""


# ── DALL-E 3 generation ───────────────────────────────────────────────────────


def generate_dalle_image(
    brand_profile: BrandProfile,
    style: str,
    theme_colors: list[str] | None = None,
) -> str | None:
    """Call DALL-E 3 to generate a logo image. Returns URL or None on failure."""
    client = _get_dalle_client()
    s = get_settings()
    allowed_palette = _build_allowed_palette(brand_profile, theme_colors)
    try:
        resp = client.images.generate(
            model=s.dalle_model,
            prompt=build_dalle_user_prompt(brand_profile, style, allowed_palette),
            size="1024x1024",
            quality="standard",
            n=1,
        )
        return resp.data[0].url
    except Exception as e:
        print(f"[logo] DALL-E generation failed: {e}")
        return None


# ── Combined entry point ──────────────────────────────────────────────────────


async def generate_logo(
    brand_profile: BrandProfile,
    style: str,
    mode: Literal["svg", "dalle", "both"] = "both",
    theme_colors: list[str] | None = None,
) -> dict[str, Any]:
    """Generate SVG and/or DALL-E logo based on mode.

    Returns {"svg": str, "image_url": str | None}
    """
    loop = asyncio.get_running_loop()
    svg: str = ""
    image_url: str | None = None

    futs = []
    if mode in ("svg", "both"):
        svg_fut = loop.run_in_executor(None, generate_svg, brand_profile, style, theme_colors)
        futs.append(("svg", svg_fut))
    if mode in ("dalle", "both"):
        dalle_fut = loop.run_in_executor(None, generate_dalle_image, brand_profile, style, theme_colors)
        futs.append(("dalle", dalle_fut))

    results = await asyncio.gather(*(f for _, f in futs), return_exceptions=True)
    for (kind, _), result in zip(futs, results):
        if isinstance(result, Exception):
            print(f"[logo] {kind} task raised: {result}")
            continue
        if kind == "svg":
            svg = result  # type: ignore[assignment]
        else:
            image_url = result  # type: ignore[assignment]

    return {"svg": svg, "image_url": image_url}
