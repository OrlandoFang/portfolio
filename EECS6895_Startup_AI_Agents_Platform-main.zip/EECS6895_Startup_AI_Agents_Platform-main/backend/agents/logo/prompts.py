"""Logo Agent — consolidated prompts.

Brand Hub passes a BrandProfile whose primary/accent hexes reflect the user's
chosen Brand Theme palette (applied server-side before the logo agent runs).
Logo Lab uses the same contract after brand extraction — always obey the
provided hex pair as the authoritative colour theme."""

from __future__ import annotations

from backend.models.brand_profile import BrandProfile


def _style_instruction(style: str) -> str:
    s = style.strip().lower()
    if s in {"minimal", "minimalist", "simple"}:
        return "Style instruction: minimalist."
    if s in {"complex", "bold"}:
        return "Style instruction: complex."
    # neutral/corporate/default: intentionally no special style constraints.
    return "Style instruction: neutral (no special style instruction)."

SVG_SYSTEM_PROMPT = """You are the Brandforge Logo Agent: a specialist in flat, timeless vector logos.

Your output MUST obey every rule below. If any rule conflicts with "being creative," follow the rule.

RULE 1 — BRAND THEME COLOURS (AUTHORITATIVE)
The user message lists PRIMARY_HEX and ACCENT_HEX. Those hex values represent the user's chosen Brand Theme from Brand Hub (or inferred profile from Logo Lab). They are legally binding:
- Every coloured stroke and fill MUST use ONLY: PRIMARY_HEX, ACCENT_HEX, pure #000000, or pure #FFFFFF.
- #000000 and #FFFFFF exist only for small-scale contrast/knockout — not as replacements for ignoring the theme.
- Do NOT introduce any third brand colour (no reds, blues, oranges, gradients, metallics, or "similar" substitutes).

RULE 2 — FULL BRAND WORDMARK (MANDATORY)
The user message states FULL_BRAND_NAME. Render that EXACT character sequence — the complete name — as legible typography (SVG <text> or equivalent paths).
- Forbidden: initials-only lockups replacing the wordmark when a full name is given, abbreviated names, placeholders like "Brand", microscopic type, faint grey-only text, omitting middle words.

RULE 3 — ONE LOGO ONLY
Deliver exactly ONE final logo composition inside a single cohesive layout (one hero mark paired with its wordmark is OK).
Forbidden in the SAME output: grids, strips, carousel/reel mocks, swipe UI, matrices, comparisons, badges of variants, watermark repeats, splash screens showing multiple unrelated marks, mood boards.

RULE 4 — TECHNICAL (SVG ONLY)
Respond with ONLY raw SVG markup. No prose, markdown, or fences. Exactly one root <svg> element. Include viewBox."""

DALLE_LOGO_PROMPT_HEADER = """BRANDFORGE LOGO — MUST FOLLOW ALL RULES WITHOUT EXCEPTION.

RULE A — SINGLE IMAGE, ONE DESIGN
One centered logo on plain white ONLY. Forbidden: collage, multi-panel grids, reels, carousel UI, side-by-side options, sticker sheets (multiple boxed logos).

RULE B — BRAND THEME COLOURS (FROM BRAND PROFILE)
Treat the PRIMARY and ACCENT hex values supplied below as mandatory. Graphic logo colour must derive strictly from those two hues plus sparing black (#000000) or white (#FFFFFF) for knockout only. Do not substitute other pigments.

RULE C — FULL BRAND WORDMARK ON-CANVAS
Render the FULL brand string provided below verbatim (complete name, spelled exactly). Typography must match the lettering — readable at thumbnail size."""

def build_svg_user_prompt(brand_profile: BrandProfile, style: str, allowed_theme_hexes: list[str]) -> str:
    """Single user turn for SVG generation."""
    bn = brand_profile.brand_name.strip() or "(unnamed)"
    tag = brand_profile.tagline.strip() if brand_profile.tagline else ""
    style_instruction = _style_instruction(style)
    tagline_block = f'Optional tagline (may appear small under wordmark ONLY if readable): "{tag}"' if tag else "Optional tagline: none."
    color_list = ", ".join(allowed_theme_hexes)

    return f"""COMPLETE THE LOGO ASSIGNMENT USING THE FOLLOWING LOCKED CONTEXT.

===== BRAND IDENTITIES (AUTHORITATIVE) =====
FULL_BRAND_NAME (render ALL characters verbatim, no truncation): "{bn}"
Industry: {brand_profile.industry}
{style_instruction}
Typography cue (preferred font vibe): {brand_profile.font_family}
{tagline_block}

===== BRAND THEME COLOURS (AUTHORITATIVE - MATCH BRAND HUB SELECTION) =====
ALLOWED_THEME_HEXES: {color_list}

Use ONLY colors listed in ALLOWED_THEME_HEXES for all brand-coloured fills and strokes. Do NOT invent harmonising tertiary colours.

===== STRUCTURE =====
Produce ONE cohesive logo composition: one emblem/symbol PLUS the FULL_BRAND_NAME as a clear wordmark in the SAME layout.
Flat vector silhouette. No flashy effects, glossy pseudo-3D, duotone unrelated to the two hexes, or fad styles.

===== OUTPUT FORMAT =====
Output ONLY the SVG source code for this single composition."""


def build_dalle_user_prompt(brand_profile: BrandProfile, style: str, allowed_theme_hexes: list[str]) -> str:
    """Dense instruction block for raster logo generation."""
    bn = brand_profile.brand_name.strip() or "Brand"
    style_instruction = _style_instruction(style)
    tag = f' Tagline to echo subtly IF space allows (secondary): "{brand_profile.tagline.strip()}".' if brand_profile.tagline else ""
    color_list = ", ".join(allowed_theme_hexes)

    return "\n".join(
        [
            DALLE_LOGO_PROMPT_HEADER,
            "",
            f"FULL_BRAND_NAME (verbatim, full wording on the image): {bn}",
            f"Industry: {brand_profile.industry}. {style_instruction}{tag}",
            f"ALLOWED_THEME_HEXES={color_list}",
            "",
            "Visual language: flat graphic vector logo, crisp edges, professional, generous white margin around the single mark.",
            "No photorealism. No device frames. No multiple logo candidates in one image.",
        ]
    )


def build_svg_system_prompt() -> str:
    return SVG_SYSTEM_PROMPT
