"""Tool registry and plan executor."""

from typing import Any, Callable


def run_plan(
    plan: dict[str, Any],
    tool_registry: dict[str, Callable[..., dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Execute plan steps in order; return trace list."""
    trace = []
    for step in plan.get("plan", []):
        tool_name = step.get("tool")
        args = step.get("args", {})

        if tool_name not in tool_registry:
            trace.append({
                "tool": tool_name,
                "args": args,
                "result": {"error": f"unknown tool '{tool_name}'"},
                "result_preview": "error: unknown tool",
            })
            continue

        try:
            result = tool_registry[tool_name](**args)
        except Exception as e:
            print(f"[warning]: tool '{tool_name}' failed: {e}")
            result = {"error": f"Tool execution failed: {e}"}

        result_str = str(result)
        trace.append({
            "tool": tool_name,
            "args": args,
            "result": result,
            "result_preview": result_str[:100] + ("..." if len(result_str) > 100 else ""),
        })

    return trace
