"""Platform chooser tool: load benchmark data for platform comparison."""

from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Any


def _normalize(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"[^\w\s]", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def _industry_matches(query: str, industry: str) -> bool:
    q = _normalize(query)
    ind = _normalize(industry)
    if not q:
        return True
    if q in ind or ind in q:
        return True
    q_tokens = set(q.split())
    ind_tokens = set(ind.split())
    return bool(q_tokens & ind_tokens)


def _load_csv(path: Path) -> list[dict[str, Any]]:
    rows = []
    if not path.exists():
        return rows
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append({k.strip(): v.strip() if isinstance(v, str) else v for k, v in row.items()})
    return rows


def _filter_by_industry(rows: list[dict], industry: str) -> list[dict]:
    if not industry:
        return rows
    return [row for row in rows if _industry_matches(industry, row.get("Industry", ""))]


def platform_chooser(
    industry: str = "",
    region: str = "US",
    include_audience: bool = True,
    **kwargs: Any,
) -> dict[str, Any]:
    """Load platform benchmarks for the given industry and region."""
    from backend.config import get_settings
    benchmarks_dir = get_settings().benchmarks_dir

    if not benchmarks_dir.exists():
        return {"status": "error", "message": "Benchmarks directory not found.", "platforms": [], "audience": []}

    region_upper = str(region).strip().upper() if region else "US"
    if region_upper not in ("US", "GLOBAL"):
        region_upper = "US"
    use_global = region_upper == "GLOBAL"

    platforms: list[dict] = []
    audience: list[dict] = []

    # Meta by industry
    meta_rows = _load_csv(benchmarks_dir / "Meta_2024Q3_By_Industry.csv")
    if meta_rows and industry:
        meta_rows = _filter_by_industry(meta_rows, industry)
    for row in meta_rows:
        platforms.append({
            "platform": row.get("Platform", "Meta Ads"),
            "industry": row.get("Industry", ""),
            "region": row.get("Region", ""),
            "avg_cpc_usd": row.get("Avg_CPC_USD", ""),
            "avg_cpm_usd": row.get("Avg_CPM_USD", ""),
            "avg_cpa_usd": row.get("Avg_CPA_USD", ""),
            "avg_ctr_pct": row.get("Avg_CTR_%", ""),
            "avg_conversion_rate_pct": row.get("Avg_Conversion_Rate_%", ""),
        })

    # Google by industry (US only)
    if not use_global:
        google_rows = _load_csv(benchmarks_dir / "Google_Ads_2025_By_Industry.csv")
        if industry:
            google_rows = _filter_by_industry(google_rows, industry)
        for row in google_rows:
            platforms.append({
                "platform": row.get("Platform", "Google Ads"),
                "industry": row.get("Industry", ""),
                "region": row.get("Region", ""),
                "avg_cpc_usd": row.get("Avg_CPC_USD", ""),
                "avg_cpm_usd": row.get("Avg_CPM_USD", ""),
                "avg_cpa_usd": row.get("Avg_CPA_USD", ""),
                "avg_ctr_pct": row.get("Avg_CTR_%", ""),
                "avg_conversion_rate_pct": row.get("Avg_Conversion_Rate_%", ""),
            })

    # CPC/CPM cross-platform
    cpc_filename = "CPC_CPM_CPA_Global_Average.csv" if use_global else "CPC_CPM_CPA_US_Only.csv"
    cpc_rows = _load_csv(benchmarks_dir / cpc_filename)
    platform_names = {p.get("platform", "").lower() for p in platforms}
    for row in cpc_rows:
        pname = (row.get("Platform") or "").strip()
        if not pname:
            continue
        include = not platforms or pname.lower() not in platform_names
        if industry and platforms and _industry_matches(industry, row.get("Industry", "")):
            include = True
        if include:
            platforms.append({
                "platform": pname,
                "industry": row.get("Industry", "General"),
                "region": row.get("Region", ""),
                "avg_cpc_usd": row.get("Avg_CPC_USD", ""),
                "avg_cpm_usd": row.get("Avg_CPM_USD", ""),
                "avg_cpa_usd": row.get("Avg_CPA_USD", ""),
                "avg_ctr_pct": row.get("Avg_CTR_%", ""),
                "avg_conversion_rate_pct": row.get("Avg_Conversion_Rate_%", ""),
                "funnel_stage": row.get("Funnel_Stage", ""),
            })
            platform_names.add(pname.lower())

    # Audience behavior
    if include_audience:
        aud_filename = "Audience_Behavior_Global_Average.csv" if use_global else "Audience_Behavior_US_Only.csv"
        aud_rows = _load_csv(benchmarks_dir / aud_filename)
        for row in aud_rows:
            audience.append({
                "platform": row.get("Platform", ""),
                "region": row.get("Region", ""),
                "age_18_24_pct": row.get("Age_18_24_%", ""),
                "age_25_34_pct": row.get("Age_25_34_%", ""),
                "age_35_44_pct": row.get("Age_35_44_%", ""),
                "mobile_usage_pct": row.get("Mobile_Usage_%", ""),
                "primary_intent": row.get("Primary_Intent", ""),
                "purchase_intent_level": row.get("Purchase_Intent_Level", ""),
                "typical_funnel_role": row.get("Typical_Funnel_Role", ""),
            })

    return {
        "status": "ok",
        "message": f"Retrieved platform benchmarks for industry '{industry}' in region {region_upper}.",
        "industry_query": industry,
        "region": region_upper,
        "platforms": platforms,
        "audience": audience,
    }
