"""RAG as a callable tool for the agent."""

from typing import Any, Callable

from backend.agents.marketing.llm.base import BaseLLM
from backend.agents.marketing.rag.pipeline import rag_answer


def make_tool_rag(retriever, llm: BaseLLM) -> Callable[..., dict[str, Any]]:
    """Build tool_rag bound to the given retriever and LLM."""

    def tool_rag(question: str, k: int = 3, **kwargs: Any) -> dict[str, Any]:
        return rag_answer(question, retriever=retriever, llm=llm, k=k)

    return tool_rag
