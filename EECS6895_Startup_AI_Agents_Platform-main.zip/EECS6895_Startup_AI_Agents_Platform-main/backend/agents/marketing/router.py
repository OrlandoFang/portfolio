"""FastAPI router for the Marketing Agent endpoint."""

from __future__ import annotations

import asyncio
import re
from typing import Any

from fastapi import APIRouter, HTTPException
from openai import OpenAI
from pydantic import BaseModel

from backend.config import get_settings
from backend.models.brand_profile import BrandProfile

router = APIRouter()


class MarketingRequest(BaseModel):
    brand_profile: BrandProfile
    user_query: str


class MarketingResponse(BaseModel):
    strategy: str
    platform_recommendations: dict[str, Any]
    citations: list[str]
    ad_poster_url: str | None = None


def _extract_citations(trace: list[dict]) -> list[str]:
    """Collect all unique doc_ids from RAG evidence in the trace."""
    seen: set[str] = set()
    result: list[str] = []
    for t in trace:
        if t.get("tool") == "rag" and isinstance(t.get("result"), dict):
            for item in t["result"].get("evidence", []):
                doc_id = item.get("doc_id")
                if doc_id and doc_id not in seen:
                    seen.add(doc_id)
                    result.append(doc_id)
    return result


def _extract_platform_recommendations(trace: list[dict]) -> dict[str, Any]:
    """Pull platform benchmark data from the platform_chooser tool result."""
    for t in trace:
        if t.get("tool") == "platform_chooser" and isinstance(t.get("result"), dict):
            r = t["result"]
            return {
                "platforms": r.get("platforms", []),
                "audience": r.get("audience", []),
                "region": r.get("region", ""),
                "industry_query": r.get("industry_query", ""),
            }
    return {}


def _get_dalle_client() -> OpenAI:
    s = get_settings()
    return OpenAI(
        api_key=s.dalle_api_key or s.openai_api_key,
        base_url=s.dalle_base_url or s.openai_base_url,
    )


def _build_ad_poster_prompt(
    *,
    brand_profile: BrandProfile,
    user_query: str,
    primary_platform: str,
) -> str:
    return (
        f"Design a single advertising poster for platform '{primary_platform}' "
        f"for brand '{brand_profile.brand_name}' in the {brand_profile.industry} industry. "
        f"Campaign intent: {user_query}. "
        f"Brand tone: {brand_profile.tone}. Font style cue: {brand_profile.font_family}. "
        f"Color constraints: use only {brand_profile.primary_color} and {brand_profile.accent_color}. "
        "Flat, modern, high-contrast layout with clear visual hierarchy and strong CTA area. "
        "The poster should look production-ready for the specified platform format. "
        "No watermark, no mockup frames, no multiple design variations."
    )


def _generate_ad_poster_sync(
    *,
    brand_profile: BrandProfile,
    user_query: str,
    platform_recommendations: dict[str, Any],
) -> str | None:
    platforms = platform_recommendations.get("platforms") if isinstance(platform_recommendations, dict) else None
    primary_platform = platforms[0] if isinstance(platforms, list) and platforms else "Instagram"
    try:
        client = _get_dalle_client()
        s = get_settings()
        resp = client.images.generate(
            model=s.dalle_model,
            prompt=_build_ad_poster_prompt(
                brand_profile=brand_profile,
                user_query=user_query,
                primary_platform=str(primary_platform),
            ),
            size="1024x1024",
            quality="standard",
            n=1,
        )
        return resp.data[0].url
    except Exception:
        return None


@router.post("/agents/marketing", response_model=MarketingResponse)
async def marketing_endpoint(req: MarketingRequest) -> MarketingResponse:
    """Run the full marketing agent pipeline for a brand."""
    try:
        from backend.agents.marketing.agent.run import run_agent
        result = await run_agent(
            question=req.user_query,
            brand_profile=req.brand_profile,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Marketing agent failed: {e}")

    platform_recommendations = _extract_platform_recommendations(result["trace"])
    loop = asyncio.get_running_loop()
    ad_poster_url = await loop.run_in_executor(
        None,
        lambda: _generate_ad_poster_sync(
            brand_profile=req.brand_profile,
            user_query=req.user_query,
            platform_recommendations=platform_recommendations,
        ),
    )

    return MarketingResponse(
        strategy=result["final_answer"],
        platform_recommendations=platform_recommendations,
        citations=_extract_citations(result["trace"]),
        ad_poster_url=ad_poster_url,
    )
