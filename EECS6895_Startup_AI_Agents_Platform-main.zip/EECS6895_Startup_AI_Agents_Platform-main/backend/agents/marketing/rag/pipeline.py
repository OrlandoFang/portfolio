"""RAG pipeline: retrieve → build messages → generate answer with evidence."""

from __future__ import annotations

from typing import Any, List

from langchain_core.documents import Document

from backend.agents.marketing.llm.base import BaseLLM

RAG_SYSTEM = (
    "You are a retrieval-augmented assistant.\n"
    "Answer the user's question using ONLY the provided context.\n"
    "You MUST cite sources using doc_id in square brackets, e.g. [meta_prohibited_content].\n"
)


def build_rag_messages(context_docs: List[Document], question: str) -> List[dict[str, str]]:
    ctx_blocks = []
    for d in context_docs:
        doc_id = d.metadata.get("doc_id", "unknown")
        ctx_blocks.append(f"[{doc_id}]\n{d.page_content.strip()}")
    context = "\n\n".join(ctx_blocks)
    user = f"Context:\n{context}\n\nQuestion: {question}"
    return [
        {"role": "system", "content": RAG_SYSTEM},
        {"role": "user", "content": user},
    ]


def rag_answer(
    question: str,
    retriever,
    llm: BaseLLM,
    k: int = 3,
    show_evidence: bool = False,
    max_new_tokens: int = 256,
) -> dict[str, Any]:
    """End-to-end RAG: retrieve → build messages → generate.

    Returns: {"answer": str, "evidence": [{"doc_id", "title", "var", "text"}, ...]}
    """
    docs = retriever.invoke(question)

    messages = build_rag_messages(docs, question)
    answer = llm.generate(messages, max_new_tokens=max_new_tokens, temperature=0.0)

    evidence = [
        {
            "doc_id": d.metadata.get("doc_id", "N/A"),
            "title": d.metadata.get("title", "N/A"),
            "var": d.metadata.get("var", ""),
            "text": d.page_content,
        }
        for d in docs
    ]
    return {"answer": answer, "evidence": evidence}
