"""FAISS vector store and retriever."""

from typing import Optional

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

try:
    from langchain_huggingface import HuggingFaceEmbeddings
except ImportError:
    from langchain_community.embeddings import HuggingFaceEmbeddings  # type: ignore


def get_embeddings(model_name: str) -> Embeddings:
    return HuggingFaceEmbeddings(model_name=model_name)


def build_vectorstore(
    documents: list[Document],
    embed_model_name: Optional[str] = None,
    embeddings: Optional[Embeddings] = None,
) -> FAISS:
    if embeddings is None:
        from backend.config import get_settings
        embeddings = get_embeddings(embed_model_name or get_settings().embed_model_name)
    return FAISS.from_documents(documents=documents, embedding=embeddings)


def get_retriever(vectorstore: FAISS, k: int = 3):
    return vectorstore.as_retriever(search_kwargs={"k": k})
