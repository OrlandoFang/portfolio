"""Marketing Agent — migrated from midterm Flask project."""
