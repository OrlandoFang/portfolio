"""Synthesizer: merge tool trace into final answer with citations."""

from __future__ import annotations

import json
import re
from typing import Any, List

from backend.agents.marketing.llm.base import BaseLLM

# Avoid circular import — import BrandProfile lazily
_BrandProfile = None


def _get_brand_profile_class():
    global _BrandProfile
    if _BrandProfile is None:
        from backend.models.brand_profile import BrandProfile
        _BrandProfile = BrandProfile
    return _BrandProfile


def _collect_rag_citations(trace: List[dict[str, Any]]) -> list[str]:
    for t in trace:
        if t.get("tool") == "rag" and isinstance(t.get("result"), dict):
            ev = t["result"].get("evidence", [])
            doc_ids = []
            for item in ev:
                doc_id = item.get("doc_id")
                if doc_id and doc_id not in doc_ids:
                    doc_ids.append(doc_id)
            return doc_ids
    return []


def _has_citation(text: str) -> bool:
    return bool(re.search(r"\[[^\[\]]+\]", text))


def _build_system(citations: list[str], brand_profile=None) -> str:
    lines = ["You are an expert advertising strategist. Use ONLY the provided tool outputs. Be concise and actionable."]
    if brand_profile:
        lines.append(
            f"\nBrand context: {brand_profile.brand_name} is a {brand_profile.industry} brand with a {brand_profile.tone} tone. "
            f"Tailor your recommendations accordingly."
        )
    if citations:
        lines.append(f"\nAvailable citations: {', '.join(f'[{c}]' for c in citations)}")
        lines.append("Include at least one citation when using RAG results.")
    return "\n".join(lines)


def synthesize_answer(
    question: str,
    trace: List[dict[str, Any]],
    llm: BaseLLM,
    max_new_tokens: int = 1024,
    brand_profile=None,
) -> str:
    """Merge tool outputs into a coherent answer with citations."""
    citations = _collect_rag_citations(trace)
    tool_blocks = []
    for t in trace:
        result_str = json.dumps(t["result"], ensure_ascii=False)
        tool_blocks.append(
            f"Tool: {t['tool']}\nArgs: {json.dumps(t['args'], ensure_ascii=False)}\n"
            f"Result: {result_str[:2000]}{'...' if len(result_str) > 2000 else ''}"
        )
    tool_text = "\n\n".join(tool_blocks)
    system = _build_system(citations, brand_profile)

    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": f"Question: {question}\n\nTool outputs:\n{tool_text}\n\nWrite the final answer:"},
    ]
    answer = llm.generate(messages, max_new_tokens=max(max_new_tokens, 1024), temperature=0.2)

    if citations and not _has_citation(answer):
        answer = answer.strip() + f"\n\nSources: [{citations[0]}]"
    return answer
