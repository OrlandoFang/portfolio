"""Router: classify user intent → JSON execution plan."""

from __future__ import annotations

from typing import Any

from backend.agents.marketing.llm.base import BaseLLM
from backend.agents.marketing.agent.utils import extract_json

ROUTER_SYSTEM = "Output strictly valid JSON only. No extra text."
MAX_RAG_STEPS = 5


def _make_router_prompt(question: str) -> str:
    return (
        f"Create an advertising research plan for the following question.\n"
        f"Return valid JSON with a 'plan' array. Each step must have 'tool' and 'args'.\n"
        f"Available tools:\n"
        f"  - platform_chooser: args={{industry, region, include_audience}}\n"
        f"  - rag: args={{question, k}}\n"
        f"Include one platform_chooser step first, then 2-4 rag steps for ad policy queries.\n\n"
        f"User question: {question}\n\nJSON:"
    )


def _fallback_plan(question: str) -> dict[str, Any]:
    industry = question.strip()[:100] if question else "General"
    return {
        "plan": [
            {"tool": "platform_chooser", "args": {"industry": industry, "region": "US", "include_audience": True}},
            {"tool": "rag", "args": {"question": f"Meta ads policy for {industry}", "k": 3}},
            {"tool": "rag", "args": {"question": f"Google Ads policy for {industry}", "k": 3}},
            {"tool": "rag", "args": {"question": "TikTok ads policy and brand safety", "k": 3}},
        ]
    }


def _cap_rag_steps(plan: dict[str, Any]) -> dict[str, Any]:
    steps = plan.get("plan", [])
    chosen = []
    rag_count = 0
    for step in steps:
        tool = step.get("tool", "")
        if tool == "platform_chooser":
            chosen.append(step)
        elif tool == "rag" and rag_count < MAX_RAG_STEPS:
            chosen.append(step)
            rag_count += 1
    return {"plan": chosen}


def route_question(question: str, llm: BaseLLM) -> dict[str, Any]:
    """Return plan = {"plan": [steps]} via LLM routing (falls back to default on failure)."""
    messages = [
        {"role": "system", "content": ROUTER_SYSTEM},
        {"role": "user", "content": _make_router_prompt(question)},
    ]
    try:
        raw = llm.generate(messages, max_new_tokens=512, temperature=0.0)
        plan = extract_json(raw)
        if "plan" not in plan or not isinstance(plan["plan"], list) or not plan["plan"]:
            raise ValueError("Invalid plan schema")
        return _cap_rag_steps(plan)
    except Exception as e:
        print(f"[warning]: router failed, using fallback plan | reason: {e}")
        return _fallback_plan(question)
