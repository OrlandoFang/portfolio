"""JSON extraction from LLM output."""

import json


def extract_json(text: str) -> dict:
    """Extract first JSON object from text (handles markdown fences and extra text)."""
    if not text:
        raise ValueError("Empty string — no JSON to extract.")

    start = text.find("{")
    if start == -1:
        raise ValueError(f"No '{{' found in text. Snippet: {text[:50]!r}")

    errors = []
    while start != -1:
        try:
            result, _ = json.JSONDecoder().raw_decode(text[start:])
            if isinstance(result, dict):
                return result
        except json.JSONDecodeError as e:
            errors.append(str(e))
        start = text.find("{", start + 1)

    raise ValueError(f"Failed to extract JSON. Errors: {errors}. Snippet: {text[:200]!r}")
