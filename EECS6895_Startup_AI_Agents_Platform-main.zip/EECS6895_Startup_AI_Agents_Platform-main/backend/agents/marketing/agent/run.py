"""Run agent: route → run_plan → synthesize."""

from __future__ import annotations

import asyncio
from typing import Any

from backend.agents.marketing.llm import get_llm
from backend.agents.marketing.llm.base import BaseLLM
from backend.agents.marketing.rag import load_jsonl_corpus, build_vectorstore, get_retriever
from backend.agents.marketing.tools import run_plan, make_tool_rag, platform_chooser
from backend.agents.marketing.agent.router import route_question
from backend.agents.marketing.agent.synthesizer import synthesize_answer

# Lazy singletons
_retriever = None
_retriever_lock = asyncio.Lock()


async def _get_default_retriever():
    """Build FAISS retriever lazily; uses asyncio lock to prevent concurrent init."""
    global _retriever
    if _retriever is not None:
        return _retriever
    async with _retriever_lock:
        if _retriever is not None:
            return _retriever
        from backend.config import get_settings
        s = get_settings()
        corpus_path = s.corpus_abs_path
        if corpus_path.exists():
            # FAISS build is CPU-bound — run in thread pool to not block event loop
            loop = asyncio.get_event_loop()
            docs = await loop.run_in_executor(None, load_jsonl_corpus, corpus_path)
            vs = await loop.run_in_executor(
                None,
                lambda: build_vectorstore(docs, embed_model_name=s.embed_model_name),
            )
            _retriever = get_retriever(vs, k=s.rag_top_k)
    return _retriever


def _build_tool_registry(llm: BaseLLM, retriever) -> dict[str, Any]:
    reg = {"platform_chooser": platform_chooser}
    if retriever is not None:
        reg["rag"] = make_tool_rag(retriever, llm)
    return reg


async def run_agent(
    question: str,
    llm: BaseLLM | None = None,
    retriever=None,
    brand_profile=None,
) -> dict[str, Any]:
    """Full agent pipeline: route → execute tools → synthesize answer."""
    llm = llm or get_llm()
    if retriever is None:
        retriever = await _get_default_retriever()
    tool_registry = _build_tool_registry(llm, retriever)

    # Router and run_plan are sync; run in thread pool to stay non-blocking
    loop = asyncio.get_event_loop()
    plan = await loop.run_in_executor(None, route_question, question, llm)
    trace = await loop.run_in_executor(None, run_plan, plan, tool_registry)
    final_answer = await loop.run_in_executor(
        None,
        lambda: synthesize_answer(question, trace, llm, brand_profile=brand_profile),
    )

    return {
        "question": question,
        "plan": plan.get("plan", []),
        "trace": trace,
        "final_answer": final_answer,
    }
