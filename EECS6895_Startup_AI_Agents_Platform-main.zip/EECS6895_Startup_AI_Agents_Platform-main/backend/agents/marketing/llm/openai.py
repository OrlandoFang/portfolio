"""OpenAI Chat Completions LLM backend."""

from __future__ import annotations

from typing import Any

from openai import OpenAI

from backend.agents.marketing.llm.base import BaseLLM
from backend.config import get_settings


class OpenAILLM(BaseLLM):
    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
    ) -> None:
        s = get_settings()
        self._client = OpenAI(
            api_key=api_key or s.openai_api_key,
            base_url=base_url or s.openai_base_url,
        )
        self.model = model or s.openai_model

    def generate(
        self,
        messages: list[dict[str, str]],
        *,
        max_new_tokens: int = 256,
        temperature: float = 0.0,
        **kwargs: Any,
    ) -> str:
        resp = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=max_new_tokens,
            temperature=temperature,
            **kwargs,
        )
        return (resp.choices[0].message.content or "").strip()
