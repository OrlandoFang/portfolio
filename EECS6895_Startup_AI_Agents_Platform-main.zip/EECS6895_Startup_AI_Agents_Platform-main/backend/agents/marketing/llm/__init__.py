"""LLM abstraction for marketing agent — OpenAI only."""

from backend.agents.marketing.llm.base import BaseLLM
from backend.agents.marketing.llm.openai import OpenAILLM

__all__ = ["BaseLLM", "OpenAILLM", "get_llm"]

_llm_instance: list[BaseLLM | None] = [None]


def get_llm() -> BaseLLM:
    """Return the OpenAI LLM singleton (lazy init on first call)."""
    if _llm_instance[0] is None:
        _llm_instance[0] = OpenAILLM()
    return _llm_instance[0]
