"""Parsing & validation helpers for Brand Agent LLM responses."""

from __future__ import annotations

import json
import re
from typing import Any

from pydantic import ValidationError

from backend.models.brand_profile import BrandProfile

# ── Style-conditioned fallbacks ────────────────────────────────────────────
_STYLE_DEFAULTS: dict[str, dict[str, str]] = {
    "minimal": {"primary_color": "#111827", "accent_color": "#9CA3AF", "font_family": "Inter", "tone": "minimal"},
    "bold": {"primary_color": "#DC2626", "accent_color": "#FBBF24", "font_family": "Poppins", "tone": "bold"},
    "playful": {"primary_color": "#22C55E", "accent_color": "#F472B6", "font_family": "Nunito", "tone": "playful"},
    "corporate": {"primary_color": "#1E3A8A", "accent_color": "#60A5FA", "font_family": "Roboto", "tone": "professional"},
}

_HEX_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
_SHORT_HEX_RE = re.compile(r"^#[0-9A-Fa-f]{3}$")


def _normalise_hex(value: str | None, default: str) -> str:
    """Coerce a colour into a 7-char hex, falling back to ``default``."""
    if not isinstance(value, str):
        return default
    v = value.strip()
    if _HEX_RE.match(v):
        return v.upper() if v.startswith("#") else f"#{v.upper()}"
    if _SHORT_HEX_RE.match(v):
        # Expand #ABC → #AABBCC
        return "#" + "".join(ch * 2 for ch in v[1:]).upper()
    # Accept "0x..." or bare 6-char hex
    stripped = v.removeprefix("0x").removeprefix("0X").lstrip("#")
    if len(stripped) == 6 and all(c in "0123456789abcdefABCDEF" for c in stripped):
        return f"#{stripped.upper()}"
    return default


def _extract_json(text: str) -> dict[str, Any] | None:
    """Pull the first JSON object out of an LLM response."""
    if not text:
        return None
    text = text.strip()
    # Strip markdown code fences if present.
    text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return None


def parse_brand_profile(
    raw: str | dict[str, Any],
    *,
    style: str,
    fallback_brand_name: str = "Untitled Brand",
) -> BrandProfile:
    """Parse an LLM payload into a validated :class:`BrandProfile`.

    Falls back to sensible style-based defaults whenever a field is missing or
    malformed, so the pipeline never blows up on a bad LLM response.
    """
    data = raw if isinstance(raw, dict) else (_extract_json(raw) or {})
    defaults = _STYLE_DEFAULTS.get(style.lower(), _STYLE_DEFAULTS["minimal"])

    coerced = {
        "brand_name": (data.get("brand_name") or fallback_brand_name).strip() or fallback_brand_name,
        "primary_color": _normalise_hex(data.get("primary_color"), defaults["primary_color"]),
        "accent_color": _normalise_hex(data.get("accent_color"), defaults["accent_color"]),
        "font_family": (data.get("font_family") or defaults["font_family"]).strip() or defaults["font_family"],
        "tone": (data.get("tone") or defaults["tone"]).strip() or defaults["tone"],
        "industry": (data.get("industry") or "general").strip() or "general",
        "tagline": data.get("tagline") if isinstance(data.get("tagline"), str) else None,
    }
    if coerced["tagline"] is not None:
        tagline = coerced["tagline"].strip()
        coerced["tagline"] = tagline[:80] if tagline else None

    try:
        return BrandProfile.model_validate(coerced)
    except ValidationError:
        # Last-resort fallback: build a 100 % valid profile from defaults.
        return BrandProfile(
            brand_name=fallback_brand_name,
            primary_color=defaults["primary_color"],
            accent_color=defaults["accent_color"],
            font_family=defaults["font_family"],
            tone=defaults["tone"],
            industry="general",
            tagline=None,
        )


def _parse_known_hex(raw: str) -> str | None:
    """Return a validated 7-char #RRGGBB or None."""
    if not isinstance(raw, str):
        return None
    v = raw.strip()
    if _HEX_RE.match(v):
        return v.upper()
    if _SHORT_HEX_RE.match(v):
        return "#" + "".join(ch * 2 for ch in v[1:]).upper()
    stripped = v.removeprefix("#").strip()
    if len(stripped) == 6 and all(c in "0123456789abcdefABCDEF" for c in stripped):
        return f"#{stripped.upper()}"
    return None


def _default_accent_for_primary(primary: str) -> str:
    """Pick a contrasting partner when only one palette swatch exists."""
    p = primary.lstrip("#")
    if len(p) != 6:
        return "#FFFFFF"
    r, g, b = int(p[0:2], 16), int(p[2:4], 16), int(p[4:6], 16)
    luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255
    return "#FFFFFF" if luminance < 0.55 else "#111827"


def apply_theme_palette(profile: BrandProfile, theme_colors: list[str] | None) -> BrandProfile:
    """Override primary/accent hexes using the user's Brand Hub palette (first two swatches)."""
    if not theme_colors:
        return profile

    normalized: list[str] = []
    seen: set[str] = set()
    for raw in theme_colors:
        hc = _parse_known_hex(raw)
        if hc and hc not in seen:
            seen.add(hc)
            normalized.append(hc)

    if not normalized:
        return profile

    primary = normalized[0]
    accent = normalized[1] if len(normalized) >= 2 else _default_accent_for_primary(primary)

    return profile.model_copy(update={"primary_color": primary, "accent_color": accent})
