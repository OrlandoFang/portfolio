"""Brand Agent service — extracts a structured BrandProfile from free text.

Pipeline:
    description + style  ──►  prompt builder  ──►  LLM (JSON mode)
                                                      │
                                                      ▼
                                              parser / validator  ──►  BrandProfile
"""

from __future__ import annotations

import asyncio
import logging

from openai import OpenAI

from backend.agents.brand.parser import parse_brand_profile
from backend.agents.brand.prompts import BRAND_SYSTEM_PROMPT, build_user_prompt
from backend.config import get_settings
from backend.models.brand_profile import BrandProfile

logger = logging.getLogger(__name__)


def _get_client() -> OpenAI:
    s = get_settings()
    return OpenAI(api_key=s.openai_api_key, base_url=s.openai_base_url)


def _call_llm_sync(description: str, style: str) -> str:
    """Synchronous LLM call (runs inside a worker thread via asyncio)."""
    client = _get_client()
    s = get_settings()
    resp = client.chat.completions.create(
        model=s.openai_model,
        messages=[
            {"role": "system", "content": BRAND_SYSTEM_PROMPT},
            {"role": "user", "content": build_user_prompt(description, style)},
        ],
        temperature=0.4,
        response_format={"type": "json_object"},
        max_tokens=600,
    )
    return (resp.choices[0].message.content or "").strip()


async def extract_brand_profile(description: str, style: str) -> BrandProfile:
    """Extract a :class:`BrandProfile` from a brand description + style preference.

    Degrades gracefully: a failing or malformed LLM response produces a
    style-based default profile rather than an exception, so the downstream
    gateway can still run the remaining agents.
    """
    if not description or not description.strip():
        logger.warning("extract_brand_profile called with empty description")
        return parse_brand_profile({}, style=style)

    settings = get_settings()
    if not settings.openai_api_key:
        logger.warning("OPENAI_API_KEY is empty — returning default BrandProfile")
        return parse_brand_profile({}, style=style)

    loop = asyncio.get_running_loop()
    try:
        raw = await loop.run_in_executor(None, _call_llm_sync, description, style)
    except Exception as exc:  # noqa: BLE001
        logger.exception("Brand Agent LLM call failed: %s", exc)
        return parse_brand_profile({}, style=style)

    return parse_brand_profile(raw, style=style)
