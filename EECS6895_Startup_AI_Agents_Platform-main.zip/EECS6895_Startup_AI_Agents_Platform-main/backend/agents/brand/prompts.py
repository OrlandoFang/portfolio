"""Prompt construction for the Brand Agent."""

from __future__ import annotations

BRAND_SYSTEM_PROMPT = (
    "You are a senior brand strategist. "
    "Given a free-text brand description and a requested style, you must "
    "produce a compact, production-ready BrandProfile as strict JSON. "
    "Rules:\n"
    "- Respond ONLY with a JSON object, no commentary, no markdown.\n"
    "- Colors must be valid 7-character hex codes (e.g. #2D6BE4).\n"
    "- font_family must be a real widely-available font (Google Fonts or system).\n"
    "- industry must be a short category (e.g. fintech, health, e-commerce, SaaS).\n"
    "- tone must be a short adjective (e.g. professional, playful, bold, minimal).\n"
    "- tagline must be <= 80 characters or null if not derivable.\n"
    "- brand_name: use the user-provided brand name if obvious, otherwise "
    "  invent a concise one that fits the description.\n"
)

BRAND_JSON_SCHEMA_HINT = (
    '{\n'
    '  "brand_name": "string",\n'
    '  "primary_color": "#RRGGBB",\n'
    '  "accent_color": "#RRGGBB",\n'
    '  "font_family": "string",\n'
    '  "tone": "string",\n'
    '  "industry": "string",\n'
    '  "tagline": "string|null"\n'
    '}'
)


def build_user_prompt(description: str, style: str) -> str:
    """Assemble the user-side prompt passed to the LLM."""
    return (
        f"Brand description:\n\"\"\"\n{description.strip()}\n\"\"\"\n\n"
        f"Requested style preference: {style}\n\n"
        "Return a BrandProfile with this exact JSON shape:\n"
        f"{BRAND_JSON_SCHEMA_HINT}\n"
    )
