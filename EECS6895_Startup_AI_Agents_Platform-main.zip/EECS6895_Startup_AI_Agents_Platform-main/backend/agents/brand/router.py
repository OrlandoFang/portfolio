"""HTTP surface for the Brand Agent (profile extraction)."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend.agents.brand.brand_agent import extract_brand_profile
from backend.models.brand_profile import BrandProfile

router = APIRouter()


class BrandExtractRequest(BaseModel):
    brand_description: str = Field(..., min_length=1)
    style: str = Field("minimal", description="minimal | bold | playful | corporate")


class BrandExtractResponse(BaseModel):
    brand_profile: BrandProfile


@router.post("/agents/brand/profile", response_model=BrandExtractResponse)
async def extract_brand_profile_endpoint(req: BrandExtractRequest) -> BrandExtractResponse:
    """Derive a BrandProfile from free text (used by Logo Lab; independent of Brand Hub projects)."""
    try:
        profile = await extract_brand_profile(req.brand_description.strip(), req.style)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Brand extraction failed: {exc}") from exc
    return BrandExtractResponse(brand_profile=profile)
