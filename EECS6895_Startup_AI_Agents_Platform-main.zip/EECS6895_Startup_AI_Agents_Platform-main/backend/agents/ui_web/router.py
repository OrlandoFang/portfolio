"""FastAPI router for the UI/Web Agent endpoint."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.models.brand_profile import BrandProfile

router = APIRouter()


class WebsiteRequest(BaseModel):
    brand_profile: BrandProfile
    style: str = "minimal"
    theme_colors: list[str] | None = None


class WebsiteResponse(BaseModel):
    html: str


@router.post("/agents/website", response_model=WebsiteResponse)
async def website_endpoint(req: WebsiteRequest) -> WebsiteResponse:
    try:
        from backend.agents.ui_web.ui_agent import generate_website

        result = await generate_website(
            req.brand_profile, style=req.style, theme_colors=req.theme_colors
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Website agent failed: {e}")

    if not result.get("html"):
        raise HTTPException(status_code=500, detail="HTML generation returned empty")

    return WebsiteResponse(html=result["html"])
