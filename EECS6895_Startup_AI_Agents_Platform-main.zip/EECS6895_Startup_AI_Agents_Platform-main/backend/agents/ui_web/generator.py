"""LLM client, sync callers, and HTML helpers for the UI/Web Agent."""

from __future__ import annotations

import logging
import re

from openai import OpenAI

from backend.agents.ui_web.prompts import (
    GEN_SYSTEM_PROMPT,
    PLAN_SYSTEM_PROMPT,
    build_gen_user_prompt,
    build_plan_user_prompt,
)
from backend.config import get_settings
from backend.models.brand_profile import BrandProfile

logger = logging.getLogger(__name__)


def _get_client() -> OpenAI:
    s = get_settings()
    return OpenAI(api_key=s.openai_api_key, base_url=s.openai_base_url)


def call_plan_llm_sync(brand_profile: BrandProfile, style: str) -> str:
    s = get_settings()
    client = _get_client()
    resp = client.chat.completions.create(
        model=s.openai_model,
        messages=[
            {"role": "system", "content": PLAN_SYSTEM_PROMPT},
            {"role": "user", "content": build_plan_user_prompt(brand_profile, style)},
        ],
        temperature=0.4,
        max_tokens=600,
    )
    return (resp.choices[0].message.content or "").strip()


def call_gen_llm_sync(
    brand_profile: BrandProfile,
    style: str,
    allowed_theme_hexes: list[str],
    plan_json: str,
) -> str:
    s = get_settings()
    client = _get_client()
    resp = client.chat.completions.create(
        model=s.openai_model,
        messages=[
            {"role": "system", "content": GEN_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": build_gen_user_prompt(
                    brand_profile, style, allowed_theme_hexes, plan_json
                ),
            },
        ],
        temperature=0.5,
        max_tokens=3000,
    )
    return (resp.choices[0].message.content or "").strip()


# ── HTML extraction & sanitization ────────────────────────────────────────

_FENCE_RE = re.compile(r"```[a-zA-Z]*\n?")
_DOCTYPE_RE = re.compile(r"<!doctype\s+html", re.IGNORECASE)
_HTML_OPEN_RE = re.compile(r"<html\b", re.IGNORECASE)
_HTML_CLOSE_RE = re.compile(r"</html\s*>", re.IGNORECASE)
_SCRIPT_RE = re.compile(
    r"<script\b([^>]*)>(.*?)</script\s*>", re.IGNORECASE | re.DOTALL
)
_ON_ATTR_RE = re.compile(
    r"\s+on[a-z]+\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]+)", re.IGNORECASE
)
_JS_URL_RE = re.compile(
    r"(href|src)\s*=\s*([\"'])\s*javascript:[^\"']*\2", re.IGNORECASE
)


def extract_html(text: str) -> str:
    if not text:
        return ""
    cleaned = _FENCE_RE.sub("", text).strip()

    doctype_match = _DOCTYPE_RE.search(cleaned)
    if doctype_match:
        start = doctype_match.start()
    else:
        html_open = _HTML_OPEN_RE.search(cleaned)
        if not html_open:
            return ""
        start = html_open.start()

    last_close = None
    for m in _HTML_CLOSE_RE.finditer(cleaned):
        last_close = m
    if last_close is None:
        return ""

    return cleaned[start : last_close.end()].strip()


def sanitize_html(html: str) -> str:
    if not html:
        return ""

    def _script_filter(match: re.Match) -> str:
        attrs = (match.group(1) or "").lower()
        if "cdn.tailwindcss.com" in attrs:
            return match.group(0)
        return ""

    out = _SCRIPT_RE.sub(_script_filter, html)
    out = _ON_ATTR_RE.sub("", out)
    out = _JS_URL_RE.sub(r'\1=\2#\2', out)
    return out.strip()
