"""UI/Web Agent — LLM prompts and deterministic fallback HTML."""

from __future__ import annotations

from backend.models.brand_profile import BrandProfile

DEFAULT_SECTIONS: list[str] = ["nav", "hero", "features", "cta", "footer"]

# Prompt constants are filled in Task 3.
PLAN_SYSTEM_PROMPT = """You are the Brandforge Web Page Planner.

Output requirements (rules — obey ALL):
1. Your ONLY output must be a valid JSON object. Do NOT wrap it in markdown fences. Do NOT add any text before or after the JSON. The first character of your response must be "{", the last character must be "}".
2. JSON shape: {"sections": [SectionPlan, ...]}.
3. Section IDs MUST be drawn ONLY from this fixed set: ["nav", "hero", "features", "cta", "footer"].
4. Output ALL FIVE sections in this order: nav, hero, features, cta, footer.
5. Per-section fields:
   - nav:      {"id":"nav",      "logo_text": str, "links": [str, ...]}                  (3-5 links)
   - hero:     {"id":"hero",     "headline": str, "subheadline": str, "cta": str}
   - features: {"id":"features", "items": [{"title": str, "desc": str}, ...]}            (3-6 items)
   - cta:      {"id":"cta",      "headline": str, "body": str, "button": str}
   - footer:   {"id":"footer",   "tagline": str, "links": [str, ...]}                    (3-6 links)
6. Match the brand's TONE and INDUSTRY in the copy.
7. Headlines must be <= 8 words. Body fields must be <= 25 words each.
8. Avoid: marketing buzzwords (synergy, revolutionary, disrupt), placeholder text ("Lorem ipsum"), section IDs not in the allowed set.
"""
GEN_SYSTEM_PROMPT = """You are the Brandforge Web Page Generator: a specialist in flat, modern landing pages.

Output requirements (rules — obey ALL):
1. OUTPUT — return exactly ONE complete HTML document. Begin with <!DOCTYPE html>. Single root <html lang="en">. No prose, no markdown fences, no commentary.
2. TAILWIND — include exactly one <script src="https://cdn.tailwindcss.com"></script> in <head>. No other <script> tags.
3. TYPOGRAPHY — link the requested FONT_FAMILY from Google Fonts in <head>. Apply it via a small <style> block (e.g. body { font-family: '<FONT_FAMILY>', system-ui, sans-serif; }).
4. PALETTE — use ONLY hex values from ALLOWED_THEME_HEXES for brand-coloured backgrounds, accents, borders, and CTAs. Neutrals (white, black, slate-50..slate-900) are allowed. Do not invent additional brand hues.
5. SECTIONS — render exactly the 5 sections in order: nav -> hero -> features -> cta -> footer. Each section gets its own <section id="..."> wrapper. Use the per-section content from the supplied PAGE OUTLINE verbatim. Do not invent extra copy.
6. NO BROKEN ASSETS — no <img src="..."> to external URLs. Use solid Tailwind color blocks or inline <svg> icons (small geometric shapes) for visual interest. Only allowed external resources: the Tailwind CDN script (rule 2) and one Google Fonts <link> (rule 3).
7. RESPONSIVE — mobile-first; use Tailwind md: and lg: breakpoints.
8. STYLE MODIFIER:
   - "minimal":   generous whitespace, light type weights, single accent.
   - "bold":      large heroes, heavy weights, more saturated accent use.
   - "playful":   rounded corners, gradient touches.
   - "corporate": tight spacing, conservative weights.
"""


def build_plan_user_prompt(brand_profile: BrandProfile, style: str) -> str:
    bn = brand_profile.brand_name.strip() or "(unnamed)"
    tag = brand_profile.tagline.strip() if brand_profile.tagline else ""
    tag_block = f'TAGLINE: "{tag}"' if tag else "TAGLINE: (none)"
    return f"""Create the page outline for the brand below.

===== BRAND CONTEXT =====
BRAND_NAME: "{bn}"
INDUSTRY: {brand_profile.industry}
TONE: {brand_profile.tone}
{tag_block}
STYLE_DIRECTIVE: {style}

===== TASK =====
Emit JSON matching the schema in the system message. Order sections nav -> hero -> features -> cta -> footer.
"""


def build_gen_user_prompt(
    brand_profile: BrandProfile,
    style: str,
    allowed_theme_hexes: list[str],
    plan_json: str,
) -> str:
    bn = brand_profile.brand_name.strip() or "(unnamed)"
    color_list = ", ".join(allowed_theme_hexes) if allowed_theme_hexes else "(none)"
    return f"""===== BRAND CONTEXT (AUTHORITATIVE) =====
BRAND_NAME: "{bn}"
INDUSTRY: {brand_profile.industry}
TONE: {brand_profile.tone}
STYLE_DIRECTIVE: {style}
FONT_FAMILY: "{brand_profile.font_family}"
ALLOWED_THEME_HEXES: {color_list}

===== PAGE OUTLINE (USE VERBATIM) =====
{plan_json}

===== OUTPUT =====
Output the complete HTML document only.
"""


# ── Fallback ────────────────────────────────────────────────────────────────


def _is_dark(hex_color: str) -> bool:
    h = hex_color.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    if len(h) != 6:
        return False
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        return False
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 128


def build_fallback_html(
    brand_profile: BrandProfile,
    theme_colors: list[str] | None = None,
) -> str:
    palette = [c for c in (theme_colors or []) if c]
    bg = palette[0] if palette else (brand_profile.primary_color or "#111827")
    accent = palette[1] if len(palette) >= 2 else (brand_profile.accent_color or "#F5A623")
    text = "#FFFFFF" if _is_dark(bg) else "#0F172A"
    btn_text = "#FFFFFF" if _is_dark(accent) else "#0F172A"
    name = brand_profile.brand_name or "Brand"
    sub = brand_profile.tagline or brand_profile.industry or "Welcome"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{name}</title>
<style>
  html, body {{ margin: 0; padding: 0; height: 100%; }}
  body {{
    background: {bg};
    color: {text};
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: flex; align-items: center; justify-content: center;
    min-height: 100vh; padding: 2rem;
  }}
  .card {{ max-width: 640px; text-align: center; }}
  h1 {{ font-size: clamp(2rem, 5vw, 3.5rem); margin: 0 0 1rem; letter-spacing: -0.02em; }}
  p  {{ font-size: 1.125rem; opacity: 0.85; margin: 0 0 2rem; }}
  a.cta {{
    display: inline-block; padding: 0.75rem 1.5rem; border-radius: 0.5rem;
    background: {accent}; color: {btn_text}; text-decoration: none; font-weight: 600;
  }}
</style>
</head>
<body>
  <main class="card">
    <h1>{name}</h1>
    <p>{sub}</p>
    <a class="cta" href="#">Learn More</a>
  </main>
</body>
</html>
"""
