"""UI/Web Agent: generate a full HTML + Tailwind landing page.

Two-step pipeline: plan (JSON outline) -> generate (HTML). On any failure,
returns a deterministic fallback page so the gateway records `done`.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any, Literal

from pydantic import BaseModel, ValidationError

from backend.agents.ui_web.generator import (
    call_gen_llm_sync,
    call_plan_llm_sync,
    extract_html,
    sanitize_html,
)
from backend.agents.ui_web.prompts import DEFAULT_SECTIONS, build_fallback_html
from backend.config import get_settings
from backend.models.brand_profile import BrandProfile

logger = logging.getLogger(__name__)


class _SectionPlan(BaseModel):
    id: Literal["nav", "hero", "features", "cta", "footer"]
    headline: str | None = None
    subheadline: str | None = None
    body: str | None = None
    cta: str | None = None
    button: str | None = None
    logo_text: str | None = None
    links: list[str] | None = None
    items: list[dict[str, str]] | None = None
    tagline: str | None = None


class _PlanOutline(BaseModel):
    sections: list[_SectionPlan]


def _backfill_section(section_id: str, brand_profile: BrandProfile) -> _SectionPlan:
    bn = brand_profile.brand_name or "Brand"
    tag = brand_profile.tagline or brand_profile.industry or "Welcome"
    if section_id == "nav":
        return _SectionPlan(
            id="nav", logo_text=bn, links=["Home", "About", "Pricing", "Contact"]
        )
    if section_id == "hero":
        return _SectionPlan(id="hero", headline=bn, subheadline=tag, cta="Get started")
    if section_id == "features":
        return _SectionPlan(
            id="features",
            items=[
                {"title": "Quality", "desc": f"Crafted for the {brand_profile.industry} space."},
                {"title": "Speed", "desc": "Fast, reliable, and built to scale."},
                {"title": "Trust", "desc": f"A {brand_profile.tone} approach you can count on."},
            ],
        )
    if section_id == "cta":
        return _SectionPlan(id="cta", headline=bn, body=tag, button="Get started")
    return _SectionPlan(id="footer", tagline=tag, links=["Privacy", "Terms", "Contact"])


_JSON_FENCE_RE = re.compile(r"```[a-zA-Z]*\n?")


def _validate_or_backfill(
    raw_json: str, brand_profile: BrandProfile
) -> _PlanOutline:
    cleaned = _JSON_FENCE_RE.sub("", raw_json).strip()
    if not cleaned:
        raise ValueError("plan LLM returned empty output")
    # Some models wrap JSON in prose; find the outermost brace pair.
    brace_start = cleaned.find("{")
    brace_end = cleaned.rfind("}")
    if brace_start >= 0 and brace_end > brace_start:
        cleaned = cleaned[brace_start : brace_end + 1]
    data = json.loads(cleaned)
    outline = _PlanOutline.model_validate(data)
    by_id = {s.id: s for s in outline.sections}
    missing = [sid for sid in DEFAULT_SECTIONS if sid not in by_id]
    if missing:
        logger.warning("ui_web: plan omitted sections, backfilling: %s", missing)
        for sid in missing:
            by_id[sid] = _backfill_section(sid, brand_profile)
    ordered = [by_id[sid] for sid in DEFAULT_SECTIONS]
    return _PlanOutline(sections=ordered)


def _build_palette(
    brand_profile: BrandProfile, theme_colors: list[str] | None
) -> list[str]:
    if theme_colors:
        seen: set[str] = set()
        out: list[str] = []
        for c in theme_colors:
            cc = (c or "").strip()
            if cc and cc not in seen:
                seen.add(cc)
                out.append(cc)
        if out:
            return out
    palette: list[str] = []
    for c in (brand_profile.primary_color, brand_profile.accent_color):
        if c and c not in palette:
            palette.append(c)
    return palette


def _fallback(
    brand_profile: BrandProfile, theme_colors: list[str] | None
) -> dict[str, Any]:
    return {
        "html": build_fallback_html(brand_profile, theme_colors),
        "sections": list(DEFAULT_SECTIONS),
    }


async def generate_website(
    brand_profile: BrandProfile,
    style: str = "minimal",
    theme_colors: list[str] | None = None,
    sections: list[str] | None = None,
) -> dict[str, Any]:
    settings = get_settings()
    if not settings.openai_api_key:
        logger.warning("ui_web: OPENAI_API_KEY empty — returning fallback HTML")
        return _fallback(brand_profile, theme_colors)

    loop = asyncio.get_running_loop()

    # Step 1 — plan
    try:
        raw_plan = await loop.run_in_executor(
            None, call_plan_llm_sync, brand_profile, style
        )
        outline = _validate_or_backfill(raw_plan, brand_profile)
    except (ValueError, json.JSONDecodeError, ValidationError) as exc:
        logger.warning("ui_web: plan step invalid JSON/schema: %s — fallback", exc)
        return _fallback(brand_profile, theme_colors)
    except Exception as exc:
        logger.exception("ui_web: plan step failed: %s — fallback", exc)
        return _fallback(brand_profile, theme_colors)

    plan_json = outline.model_dump_json()
    palette = _build_palette(brand_profile, theme_colors)

    # Step 2 — generate
    try:
        raw_html = await loop.run_in_executor(
            None, call_gen_llm_sync, brand_profile, style, palette, plan_json
        )
        html = sanitize_html(extract_html(raw_html))
    except Exception as exc:
        logger.exception("ui_web: generate step failed: %s — fallback", exc)
        return _fallback(brand_profile, theme_colors)

    if not html:
        logger.warning(
            "ui_web: generate step produced empty HTML after extract/sanitize — fallback"
        )
        return _fallback(brand_profile, theme_colors)

    return {"html": html, "sections": list(DEFAULT_SECTIONS)}
