"""Projects REST API.

Flow of ``POST /api/projects``::

    request (brand_description, style, outputs)
        │
        ▼
    insert project doc (status="pending") in MongoDB
        │
        ▼
    kick off a background task that:
        1. runs the Brand Agent to get a BrandProfile
        2. persists the profile back on the project
        3. calls the AI Gateway → parallel fan-out to sub-agents
        4. gateway writes per-agent job rows + patches the project doc
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status

from backend.agents.brand.brand_agent import extract_brand_profile
from backend.agents.brand.parser import apply_theme_palette
from backend.agents.gateway.gateway import dispatch
from backend.api.deps import CurrentUser, get_current_user
from backend.db import projects_collection
from backend.models.project import (
    ALLOWED_OUTPUTS,
    CreateProjectRequest,
    Project,
    ProjectResult,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/projects", tags=["projects"])


# ── Helpers ────────────────────────────────────────────────────────────────
def _validate_outputs(outputs: list[str]) -> list[str]:
    cleaned = [o for o in outputs if o in ALLOWED_OUTPUTS]
    if not cleaned:
        raise HTTPException(
            status_code=400,
            detail=f"At least one of {ALLOWED_OUTPUTS} must be requested.",
        )
    return cleaned


async def _load_project(project_id: str) -> Project:
    doc = await projects_collection().find_one({"_id": project_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Project not found")
    return Project.from_mongo(doc)


# ── Routes ─────────────────────────────────────────────────────────────────
@router.post("", response_model=ProjectResult, status_code=status.HTTP_202_ACCEPTED)
async def create_project(
    req: CreateProjectRequest,
    background_tasks: BackgroundTasks,
    user: CurrentUser = Depends(get_current_user),
) -> ProjectResult:
    """Create a new project document and kick off the generation pipeline."""
    outputs = _validate_outputs(req.outputs)

    project = Project(
        id=str(uuid.uuid4()),
        user_id=user.user_id,
        brand_description=req.brand_description,
        style=req.style,
        theme_colors=req.theme_colors,
        outputs=outputs,
        status="pending",
    )

    try:
        await projects_collection().insert_one(project.to_mongo())
    except Exception as exc:  # noqa: BLE001
        logger.exception("Failed to insert project into MongoDB")
        raise HTTPException(status_code=500, detail=f"DB insert failed: {exc}") from exc

    background_tasks.add_task(
        _run_pipeline,
        project.id,
        req.brand_description,
        req.style,
        outputs,
        req.theme_colors,
    )
    return ProjectResult.from_project(project)


@router.get("/{project_id}", response_model=ProjectResult)
async def get_project(
    project_id: str,
    user: CurrentUser = Depends(get_current_user),
) -> ProjectResult:
    """Poll job status and results for a project."""
    project = await _load_project(project_id)
    if project.user_id != user.user_id:
        raise HTTPException(status_code=403, detail="Not your project")
    return ProjectResult.from_project(project)


@router.get("", response_model=list[ProjectResult])
async def list_projects(
    user: CurrentUser = Depends(get_current_user),
    limit: int = 50,
) -> list[ProjectResult]:
    """List projects for the authenticated user."""
    cursor = (
        projects_collection()
        .find({"user_id": user.user_id})
        .sort("created_at", -1)
        .limit(max(1, min(limit, 200)))
    )
    docs = await cursor.to_list(length=limit)
    return [ProjectResult.from_project(Project.from_mongo(d)) for d in docs]


# ── Background pipeline ───────────────────────────────────────────────────
async def _set_status(project_id: str, **fields) -> None:
    fields.setdefault("updated_at", datetime.utcnow().isoformat())
    try:
        await projects_collection().update_one({"_id": project_id}, {"$set": fields})
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to update project %s: %s", project_id, exc)


async def _run_pipeline(
    project_id: str,
    brand_description: str,
    style: str,
    outputs: list[str],
    theme_colors: list[str] | None = None,
) -> None:
    """Background task: Brand Agent → Gateway → patch project doc."""
    await _set_status(project_id, status="running")
    try:
        brand_profile = await extract_brand_profile(brand_description, style)
        brand_profile = apply_theme_palette(brand_profile, theme_colors)
        await _set_status(project_id, brand_profile=brand_profile.model_dump())

        await dispatch(
            brand_profile,
            outputs,
            project_id=project_id,
            persist=True,
            style=style,
            theme_colors=theme_colors,
        )
        # Gateway already sets final status on success; mark as done as a
        # safety net in case the gateway could not patch the project.
        await _set_status(project_id, status="done")
    except Exception as exc:  # noqa: BLE001
        logger.exception("Pipeline failed for project %s", project_id)
        await _set_status(project_id, status="error", error=str(exc))
