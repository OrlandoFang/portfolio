"""Internal agent passthrough — registers agent sub-routers."""

from fastapi import APIRouter

from backend.agents.brand.router import router as brand_router
from backend.agents.marketing.router import router as marketing_router
from backend.agents.logo.router import router as logo_router
from backend.agents.ui_web.router import router as website_router

# This router just re-exports the agent routers for inclusion in main.py
router = APIRouter(tags=["agents"])
router.include_router(brand_router)
router.include_router(marketing_router)
router.include_router(logo_router)
router.include_router(website_router)
