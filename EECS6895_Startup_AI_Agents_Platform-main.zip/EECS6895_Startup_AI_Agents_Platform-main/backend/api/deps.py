"""Reusable FastAPI dependencies (auth, etc.).

Auth design (minimal for a course project):
- Client POSTs an API key to /api/auth/token and receives a JWT.
- Protected endpoints expect ``Authorization: Bearer <jwt>``.
- ``get_current_user`` decodes the JWT and returns a light-weight user object
  (just ``user_id`` for now). In dev mode, if ``AUTH_ALLOW_ANONYMOUS=True``
  the dependency falls back to a fixed ``dev-user`` so the frontend can be
  iterated on without touching auth.
"""

from __future__ import annotations

from dataclasses import dataclass

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt

from backend.config import get_settings

# ``auto_error=False`` so we can fall back to a dev-user when no header is set.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token", auto_error=False)

DEV_USER_ID = "dev-user"


@dataclass
class CurrentUser:
    user_id: str


def _decode_token(token: str) -> dict:
    s = get_settings()
    try:
        return jwt.decode(token, s.jwt_secret, algorithms=[s.jwt_algorithm])
    except JWTError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid or expired token: {exc}",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


async def get_current_user(token: str | None = Depends(oauth2_scheme)) -> CurrentUser:
    """Return the authenticated user, or a dev fallback if no token is provided.

    For the course project we intentionally allow anonymous requests to make
    frontend integration easier; swap ``DEV_USER_ID`` for a 401 when deploying.
    """
    if not token:
        return CurrentUser(user_id=DEV_USER_ID)
    payload = _decode_token(token)
    sub = payload.get("sub")
    if not sub:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token missing 'sub' claim",
        )
    return CurrentUser(user_id=sub)
