"""Auth router — exchange API key for a JWT access token.

This is intentionally minimal for a course project:
- A small set of "API keys" are accepted (a dev key, plus anything matching
  a record in the ``users`` collection once user signup is added).
- On success we return a short-lived JWT that downstream endpoints verify via
  ``backend.api.deps.get_current_user``.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from jose import jwt
from pydantic import BaseModel, Field

from backend.api.deps import CurrentUser, get_current_user
from backend.config import get_settings
from backend.db import users_collection

router = APIRouter(prefix="/api/auth", tags=["auth"])


# ── Schemas ────────────────────────────────────────────────────────────────
class TokenRequest(BaseModel):
    api_key: str = Field(..., min_length=1)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class MeResponse(BaseModel):
    user_id: str


# ── Helpers ────────────────────────────────────────────────────────────────
DEV_API_KEY = "dev-key"


def create_access_token(user_id: str, *, expires_minutes: int | None = None) -> tuple[str, int]:
    """Create and sign a JWT for ``user_id``. Returns ``(token, expires_in_seconds)``."""
    s = get_settings()
    exp_minutes = expires_minutes or s.access_token_expire_minutes
    now = datetime.now(timezone.utc)
    exp = now + timedelta(minutes=exp_minutes)
    payload = {
        "sub": user_id,
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
    }
    token = jwt.encode(payload, s.jwt_secret, algorithm=s.jwt_algorithm)
    return token, exp_minutes * 60


async def _resolve_user_from_api_key(api_key: str) -> str | None:
    """Return a ``user_id`` for a given API key, or ``None`` if unknown.

    In dev we accept the fixed DEV_API_KEY. Any other key is looked up in the
    ``users`` collection: ``{"user_id": "...", "api_key": "..."}``.
    """
    if api_key == DEV_API_KEY:
        return "dev-user"
    try:
        doc = await users_collection().find_one({"api_key": api_key})
    except Exception:
        # Mongo not available (e.g. unit test without a running instance):
        # fall back to rejecting the key rather than crashing.
        return None
    return doc.get("user_id") if doc else None


# ── Routes ─────────────────────────────────────────────────────────────────
@router.post("/token", response_model=TokenResponse)
async def get_token(req: TokenRequest) -> TokenResponse:
    """Exchange an API key for a short-lived JWT."""
    user_id = await _resolve_user_from_api_key(req.api_key)
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unknown API key",
        )
    token, expires_in = create_access_token(user_id)
    return TokenResponse(access_token=token, expires_in=expires_in)


@router.get("/me", response_model=MeResponse)
async def get_me(user: CurrentUser = Depends(get_current_user)) -> MeResponse:
    """Debug helper: echo back the authenticated user."""
    return MeResponse(user_id=user.user_id)
