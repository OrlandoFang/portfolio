"""GenerationJob model tracks per-agent job status in the jobs collection."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

JobStatus = Literal["pending", "running", "done", "error"]
AgentType = Literal["website", "logo", "marketing", "brand"]


class GenerationJob(BaseModel):
    project_id: str
    agent_type: str  # one of AgentType, kept as str for forward-compat
    status: JobStatus = "pending"
    output: dict[str, Any] | None = None
    error: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    def to_mongo(self) -> dict[str, Any]:
        return self.model_dump(mode="json")
