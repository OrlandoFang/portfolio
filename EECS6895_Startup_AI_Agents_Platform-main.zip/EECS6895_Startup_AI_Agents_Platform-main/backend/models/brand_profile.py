"""Shared BrandProfile model — source of truth for all agents."""

from __future__ import annotations

from pydantic import BaseModel, Field


class BrandProfile(BaseModel):
    brand_name: str = Field(..., description="Name of the brand")
    primary_color: str = Field(..., description="Primary brand color as hex, e.g. '#2D6BE4'")
    accent_color: str = Field(..., description="Accent color as hex, e.g. '#F5A623'")
    font_family: str = Field(..., description="Font family name, e.g. 'Inter', 'Playfair Display'")
    tone: str = Field(..., description="Brand tone: professional, playful, bold, minimal, etc.")
    industry: str = Field(..., description="Industry category: fintech, health, e-commerce, etc.")
    tagline: str | None = Field(None, description="Optional brand tagline")
