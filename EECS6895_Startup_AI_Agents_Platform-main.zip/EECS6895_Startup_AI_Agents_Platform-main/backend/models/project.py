"""Project models: request, DB document, response."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

from backend.models.brand_profile import BrandProfile

ProjectStatus = Literal["pending", "running", "done", "error"]
ALLOWED_OUTPUTS = ("website", "logo", "marketing")


class CreateProjectRequest(BaseModel):
    brand_description: str = Field(..., min_length=1, description="Free-text description of the brand")
    style: str = Field("minimal", description="Style preference: minimal | bold | playful | corporate")
    outputs: list[str] = Field(
        default_factory=lambda: list(ALLOWED_OUTPUTS),
        description="Requested output types",
    )
    theme_colors: list[str] | None = Field(
        default=None,
        description="Brand Hub palette: hex colors in order — first = primary, second = accent.",
    )


class AgentResult(BaseModel):
    """Per-agent result captured by the gateway for partial-failure reporting."""

    status: Literal["pending", "running", "done", "error"] = "pending"
    output: dict[str, Any] | None = None
    error: str | None = None


class Project(BaseModel):
    """Canonical project document stored in MongoDB."""

    id: str = Field(..., description="UUID primary key (mapped to Mongo _id).")
    user_id: str
    brand_description: str | None = None
    style: str | None = None
    theme_colors: list[str] | None = None
    outputs: list[str] = Field(default_factory=list)
    brand_profile: BrandProfile | None = None
    status: ProjectStatus = "pending"
    results: dict[str, AgentResult] = Field(default_factory=dict)
    error: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    def to_mongo(self) -> dict[str, Any]:
        """Dump to a dict using ``_id`` for the primary key (Mongo convention)."""
        doc = self.model_dump(mode="json")
        doc["_id"] = doc.pop("id")
        return doc

    @classmethod
    def from_mongo(cls, doc: dict[str, Any]) -> "Project":
        data = dict(doc)
        if "_id" in data and "id" not in data:
            data["id"] = data.pop("_id")
        return cls.model_validate(data)


class ProjectResult(BaseModel):
    """Client-facing shape returned by the REST API (shared contract)."""

    project_id: str
    status: ProjectStatus
    style: str | None = None
    theme_colors: list[str] | None = None
    brand_profile: BrandProfile | None = None
    website_html: str | None = None
    logo_svg: str | None = None
    logo_image_url: str | None = None
    marketing_strategy: str | None = None
    platform_recommendations: dict | None = None

    @classmethod
    def from_project(cls, proj: Project) -> "ProjectResult":
        def _out(agent: str) -> dict[str, Any]:
            r = proj.results.get(agent)
            return (r.output or {}) if r else {}

        logo_out = _out("logo")
        marketing_out = _out("marketing")
        website_out = _out("website")

        return cls(
            project_id=proj.id,
            status=proj.status,
            style=proj.style,
            theme_colors=proj.theme_colors,
            brand_profile=proj.brand_profile,
            website_html=website_out.get("html"),
            logo_svg=logo_out.get("svg"),
            logo_image_url=logo_out.get("image_url"),
            marketing_strategy=marketing_out.get("strategy"),
            platform_recommendations=marketing_out.get("platform_recommendations") or None,
        )
