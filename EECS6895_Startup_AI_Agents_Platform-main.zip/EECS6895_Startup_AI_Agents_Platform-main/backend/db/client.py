"""Async MongoDB client via Motor.

Exposes a singleton `AsyncIOMotorClient`, typed collection accessors, and
startup/shutdown helpers that create the indexes required by the application.
"""

from __future__ import annotations

import logging
from typing import Final

from motor.motor_asyncio import (
    AsyncIOMotorClient,
    AsyncIOMotorCollection,
    AsyncIOMotorDatabase,
)

from backend.config import get_settings

logger = logging.getLogger(__name__)

# Collection names kept as module-level constants so the rest of the code can
# import them without typos.
USERS_COLLECTION: Final[str] = "users"
PROJECTS_COLLECTION: Final[str] = "projects"
JOBS_COLLECTION: Final[str] = "jobs"

_client: AsyncIOMotorClient | None = None


def get_client() -> AsyncIOMotorClient:
    """Return the process-wide Motor client, creating it lazily."""
    global _client
    if _client is None:
        settings = get_settings()
        _client = AsyncIOMotorClient(settings.mongodb_uri)
    return _client


def get_db() -> AsyncIOMotorDatabase:
    """Return the configured application database."""
    settings = get_settings()
    return get_client()[settings.mongodb_db]


# ── Collection accessors ────────────────────────────────────────────────────
def users_collection() -> AsyncIOMotorCollection:
    return get_db()[USERS_COLLECTION]


def projects_collection() -> AsyncIOMotorCollection:
    return get_db()[PROJECTS_COLLECTION]


def jobs_collection() -> AsyncIOMotorCollection:
    return get_db()[JOBS_COLLECTION]


# ── Lifecycle ──────────────────────────────────────────────────────────────
async def init_db() -> None:
    """Create required indexes. Safe to call on every startup (idempotent)."""
    try:
        await projects_collection().create_index("user_id")
        await projects_collection().create_index("status")
        await projects_collection().create_index("created_at")

        await jobs_collection().create_index("project_id")
        await jobs_collection().create_index([("project_id", 1), ("agent_type", 1)])

        await users_collection().create_index("user_id", unique=True)
        await users_collection().create_index("api_key", unique=True, sparse=True)
        logger.info("MongoDB indexes initialised")
    except Exception as exc:  # noqa: BLE001
        # Do not crash the app if Mongo is unreachable in local dev — just log it.
        logger.warning("init_db failed (continuing without indexes): %s", exc)


async def close_db() -> None:
    """Close the singleton client (call on shutdown)."""
    global _client
    if _client is not None:
        _client.close()
        _client = None
