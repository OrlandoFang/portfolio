"""Pytest configuration for backend async tests."""

from __future__ import annotations

import inspect

import pytest


def pytest_collection_modifyitems(config, items):
    for item in items:
        if "asyncio" not in item.keywords and item.get_closest_marker("asyncio") is None:
            func = getattr(item, "function", None)
            if func is not None and inspect.iscoroutinefunction(func):
                item.add_marker(pytest.mark.asyncio)
