"""Quick smoke test: call the LLM with the same client config as agents use."""

from __future__ import annotations

from backend.config import get_settings
from openai import OpenAI


def main():
    s = get_settings()
    print(f"base_url: {s.openai_base_url}")
    print(f"model:    {s.openai_model}")
    print(f"key:      {s.openai_api_key[:12]}... (len={len(s.openai_api_key)})")

    client = OpenAI(api_key=s.openai_api_key, base_url=s.openai_base_url)
    resp = client.chat.completions.create(
        model=s.openai_model,
        messages=[{"role": "user", "content": "Introduce yourself in one sentence."}],
        max_tokens=80,
    )
    print(f"\nResponse: {resp.choices[0].message.content}")
    print("OK — API key is valid.")


if __name__ == "__main__":
    main()
