"""Tests for the UI/Web Agent — no live LLM calls."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from backend.agents.ui_web.generator import extract_html, sanitize_html
from backend.agents.ui_web.prompts import build_fallback_html
from backend.agents.ui_web.ui_agent import _validate_or_backfill, generate_website
from backend.models.brand_profile import BrandProfile


def _make_profile(**overrides) -> BrandProfile:
    kwargs = dict(
        brand_name="Lumen",
        primary_color="#0F172A",
        accent_color="#F59E0B",
        font_family="Inter",
        tone="professional",
        industry="fintech",
        tagline="Clarity for your finances",
    )
    kwargs.update(overrides)
    return BrandProfile(**kwargs)


def test_fallback_returns_valid_html():
    html = build_fallback_html(_make_profile(), ["#FF0000", "#00FF00"])
    assert html.startswith("<!DOCTYPE html>")
    assert "</html>" in html
    assert "Lumen" in html
    assert "#FF0000" in html
    assert "#00FF00" in html


_CANNED_PLAN = json.dumps({
    "sections": [
        {"id": "nav", "logo_text": "Lumen", "links": ["Home", "Pricing", "About"]},
        {"id": "hero", "headline": "Clear money", "subheadline": "Simple banking.", "cta": "Start"},
        {"id": "features", "items": [
            {"title": "Fast", "desc": "Instant transfers."},
            {"title": "Safe", "desc": "Bank-grade security."},
            {"title": "Open", "desc": "No hidden fees."},
        ]},
        {"id": "cta", "headline": "Try Lumen", "body": "Sign up today.", "button": "Get started"},
        {"id": "footer", "tagline": "Clarity for your finances", "links": ["Privacy", "Terms"]},
    ]
})

_CANNED_HTML = """<!DOCTYPE html>
<html lang="en">
<head><script src="https://cdn.tailwindcss.com"></script></head>
<body><section id="hero"><h1>Lumen</h1></section></body>
</html>"""


@pytest.mark.asyncio
async def test_generate_website_smoke():
    with patch("backend.agents.ui_web.ui_agent.call_plan_llm_sync", return_value=_CANNED_PLAN), \
         patch("backend.agents.ui_web.ui_agent.call_gen_llm_sync", return_value=_CANNED_HTML), \
         patch("backend.agents.ui_web.ui_agent.get_settings") as mock_settings:
        mock_settings.return_value.openai_api_key = "sk-test"
        result = await generate_website(_make_profile(), style="minimal", theme_colors=["#0F172A"])
    assert set(result.keys()) == {"html", "sections"}
    assert result["html"].startswith("<!DOCTYPE html>")
    assert result["sections"] == ["nav", "hero", "features", "cta", "footer"]


@pytest.mark.asyncio
async def test_generate_website_fallback_on_llm_error():
    with patch("backend.agents.ui_web.ui_agent.call_plan_llm_sync", side_effect=RuntimeError("boom")), \
         patch("backend.agents.ui_web.ui_agent.get_settings") as mock_settings:
        mock_settings.return_value.openai_api_key = "sk-test"
        result = await generate_website(_make_profile())
    assert result["html"].startswith("<!DOCTYPE html>")
    assert "Lumen" in result["html"]
    assert result["sections"] == ["nav", "hero", "features", "cta", "footer"]


@pytest.mark.asyncio
async def test_generate_website_backfills_missing_section():
    plan_missing_cta = json.dumps({
        "sections": [
            {"id": "nav", "logo_text": "Lumen", "links": ["Home"]},
            {"id": "hero", "headline": "X", "subheadline": "Y", "cta": "Z"},
            {"id": "features", "items": [{"title": "A", "desc": "B"}]},
            {"id": "footer", "tagline": "T", "links": ["P"]},
        ]
    })
    captured: dict[str, str] = {}

    def _capture_gen(brand_profile, style, allowed, plan_json):
        captured["plan_json"] = plan_json
        return _CANNED_HTML

    with patch("backend.agents.ui_web.ui_agent.call_plan_llm_sync", return_value=plan_missing_cta), \
         patch("backend.agents.ui_web.ui_agent.call_gen_llm_sync", side_effect=_capture_gen), \
         patch("backend.agents.ui_web.ui_agent.get_settings") as mock_settings:
        mock_settings.return_value.openai_api_key = "sk-test"
        result = await generate_website(_make_profile())

    forwarded = json.loads(captured["plan_json"])
    forwarded_ids = [s["id"] for s in forwarded["sections"]]
    assert forwarded_ids == ["nav", "hero", "features", "cta", "footer"]
    assert result["html"] == _CANNED_HTML


# ── Content-focused tests ──────────────────────────────────────────────────


def test_extract_html_strips_fences_and_trims():
    raw = '```html\n<!DOCTYPE html>\n<html lang="en"><head></head><body><p>Hi</p></body></html>\n```'
    result = extract_html(raw)
    assert result.startswith("<!DOCTYPE html>")
    assert result.endswith("</html>")
    assert "```" not in result


def test_extract_html_returns_empty_on_garbage():
    assert extract_html("") == ""
    assert extract_html("just some random text") == ""


def test_sanitize_html_keeps_tailwind_cdn():
    html = '<head><script src="https://cdn.tailwindcss.com"></script></head>'
    assert "cdn.tailwindcss.com" in sanitize_html(html)


def test_sanitize_html_strips_other_scripts():
    html = '<script>alert("xss")</script><p>safe</p>'
    result = sanitize_html(html)
    assert "alert" not in result
    assert "<p>safe</p>" in result


def test_sanitize_html_strips_on_handlers():
    html = '<div onclick="steal()" onload="bad()">text</div>'
    result = sanitize_html(html)
    assert "onclick" not in result
    assert "onload" not in result
    assert "text" in result


def test_fallback_uses_brand_profile_content():
    profile = _make_profile(
        brand_name="EcoBrew", tagline="Tea, naturally", industry="beverage"
    )
    html = build_fallback_html(profile, ["#0E5F4F", "#F2E9DC"])
    assert "EcoBrew" in html
    assert "Tea, naturally" in html
    assert "#0E5F4F" in html
    assert "#F2E9DC" in html


def test_fallback_no_tagline_uses_industry():
    profile = _make_profile(tagline=None, industry="healthcare")
    html = build_fallback_html(profile, None)
    assert "healthcare" in html


def test_fallback_empty_name_uses_default():
    profile = _make_profile(brand_name="")
    html = build_fallback_html(profile, None)
    assert "Brand" in html


@pytest.mark.asyncio
async def test_generate_website_empty_api_key_returns_fallback():
    with patch("backend.agents.ui_web.ui_agent.get_settings") as mock_settings:
        mock_settings.return_value.openai_api_key = ""
        result = await generate_website(_make_profile())
    assert result["html"].startswith("<!DOCTYPE html>")
    assert "Lumen" in result["html"]


_CANNED_RICH_HTML = """<!DOCTYPE html>
<html lang="en">
<head><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-[#0F172A]">
<section id="nav"><nav>Lumen</nav></section>
<section id="hero"><h1>Clear money</h1><p>Simple banking.</p></section>
<section id="features"><div>Fast. Safe. Open.</div></section>
<section id="cta"><button>Get started</button></section>
<section id="footer"><small>Clarity for your finances</small></section>
</body>
</html>"""


@pytest.mark.asyncio
async def test_generate_website_preserves_section_content():
    """Generated HTML contains the brand copy from the plan outline."""
    with patch("backend.agents.ui_web.ui_agent.call_plan_llm_sync", return_value=_CANNED_PLAN), \
         patch("backend.agents.ui_web.ui_agent.call_gen_llm_sync", return_value=_CANNED_RICH_HTML), \
         patch("backend.agents.ui_web.ui_agent.get_settings") as mock_settings:
        mock_settings.return_value.openai_api_key = "sk-test"
        result = await generate_website(_make_profile())

    assert "Clear money" in result["html"]
    assert "Simple banking" in result["html"]
    assert "Fast. Safe. Open." in result["html"]
    assert "Get started" in result["html"]
    assert "Clarity for your finances" in result["html"]


@pytest.mark.asyncio
async def test_generate_website_fallback_when_gen_returns_empty():
    with patch("backend.agents.ui_web.ui_agent.call_plan_llm_sync", return_value=_CANNED_PLAN), \
         patch("backend.agents.ui_web.ui_agent.call_gen_llm_sync", return_value=""), \
         patch("backend.agents.ui_web.ui_agent.get_settings") as mock_settings:
        mock_settings.return_value.openai_api_key = "sk-test"
        result = await generate_website(_make_profile())
    assert "Lumen" in result["html"]
    assert result["html"].startswith("<!DOCTYPE html>")


def test_validate_or_backfill_strips_markdown_fences():
    raw = '```json\n{"sections":[]}\n```'
    outline = _validate_or_backfill(raw, _make_profile())
    assert len(outline.sections) == 5  # backfilled all 5


def test_validate_or_backfill_empty_string_raises():
    with pytest.raises(ValueError, match="empty"):
        _validate_or_backfill("", _make_profile())
