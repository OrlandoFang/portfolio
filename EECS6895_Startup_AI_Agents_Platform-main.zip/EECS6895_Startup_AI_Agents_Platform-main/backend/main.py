"""FastAPI application entry point.

Run locally:
    uvicorn backend.main:app --reload --port 8000
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from backend.api.agents import router as agents_router
from backend.api.auth import router as auth_router
from backend.api.projects import router as projects_router
from backend.config import get_settings
from backend.db import close_db, init_db

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    try:
        yield
    finally:
        await close_db()


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="Brandforge AI",
        description="AI-powered creative platform: landing page, logo, and marketing strategy.",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Allow the Vite frontend during development; add more origins as needed.
    cors_origins = [settings.frontend_origin]
    if settings.frontend_origin != "*":
        # Cover the common dev origins (React CRA + Vite on both hostnames).
        cors_origins.extend(
            [
                "http://localhost:3000",
                "http://127.0.0.1:3000",
                "http://localhost:5173",
                "http://127.0.0.1:5173",
            ]
        )
        cors_origins = list(dict.fromkeys(cors_origins))  # de-dupe, preserve order

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Routers ────────────────────────────────────────────────────────────
    app.include_router(auth_router)
    app.include_router(projects_router)
    app.include_router(agents_router)

    # ── Basic routes ───────────────────────────────────────────────────────
    @app.get("/health", tags=["health"])
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/", tags=["health"])
    async def root() -> dict[str, str]:
        return {"service": "brandforge-ai", "docs": "/docs"}

    # ── Exception handlers ─────────────────────────────────────────────────
    @app.exception_handler(RequestValidationError)
    async def on_request_validation_error(request: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content={"error": "validation_error", "detail": exc.errors()},
        )

    @app.exception_handler(ValidationError)
    async def on_pydantic_validation_error(request: Request, exc: ValidationError):
        return JSONResponse(
            status_code=422,
            content={"error": "validation_error", "detail": exc.errors()},
        )

    @app.exception_handler(Exception)
    async def on_unhandled_exception(request: Request, exc: Exception):
        logger.exception("Unhandled exception for %s %s", request.method, request.url.path)
        return JSONResponse(
            status_code=500,
            content={"error": "internal_server_error", "detail": str(exc)},
        )

    return app


app = create_app()
