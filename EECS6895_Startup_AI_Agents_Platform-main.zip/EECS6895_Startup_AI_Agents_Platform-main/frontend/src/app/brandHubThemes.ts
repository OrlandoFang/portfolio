/** Brand Hub theme names and swatches (must stay in sync with UI labels). */

export type BrandHubThemeOption = {
  name: string;
  colors: string[];
};

export const BRAND_HUB_THEME_OPTIONS: BrandHubThemeOption[] = [
  { name: "Choose your own palette", colors: [] },
  {
    name: "Neutral Foundation",
    colors: ["#0D0F14", "#181B24", "#2A2D38", "#9CA3AF", "#FFFFFF"],
  },
  {
    name: "Warm Spectrum",
    colors: ["#FF4500", "#FF6347", "#FFA500", "#FFD700", "#FFDAB9", "#FFF8DC"],
  },
  {
    name: "Cool Spectrum",
    colors: ["#4169E1", "#1E90FF", "#00CED1", "#20B2AA", "#3CB371", "#98FB98"],
  },
];

/**
 * Colors sent with Brand Hub projects: first swatch becomes primary,
 * second becomes accent on the backend. Logo Lab does not call this.
 */
export function resolveBrandHubThemeColors(
  selectedPalette: string,
  customColors: string[],
): string[] | undefined {
  if (selectedPalette === "Choose your own palette") {
    return customColors.length > 0 ? [...customColors] : undefined;
  }
  const row = BRAND_HUB_THEME_OPTIONS.find((t) => t.name === selectedPalette);
  if (!row?.colors?.length) return undefined;
  return [...row.colors];
}
