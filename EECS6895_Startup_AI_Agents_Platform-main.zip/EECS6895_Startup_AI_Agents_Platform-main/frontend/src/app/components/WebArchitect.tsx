import { Monitor, Smartphone, Tablet, Zap, Loader2, AlertCircle } from "lucide-react";
import { usePersistedState } from "../hooks/usePersistedState";
import { requestWebsiteAgent } from "../api/agents";
import type { BrandProfile } from "../api/projects";

type Status = "idle" | "generating" | "done" | "error";

const TONE_OPTIONS = ["professional", "friendly", "bold", "playful", "minimal"];
const FONT_OPTIONS = ["Inter", "Roboto", "Montserrat", "Poppins", "Lora"];
const STYLE_OPTIONS = [
  { id: "minimal", label: "Minimal" },
  { id: "bold", label: "Bold" },
  { id: "playful", label: "Playful" },
  { id: "corporate", label: "Corporate" },
];

const DEVICE_OPTIONS = [
  { id: "desktop", label: "Desktop", icon: Monitor },
  { id: "tablet", label: "Tablet", icon: Tablet },
  { id: "mobile", label: "Mobile", icon: Smartphone },
] as const;

export function WebArchitect() {
  const [brandName, setBrandName] = usePersistedState("web-architect:brand-name", "");
  const [industry, setIndustry] = usePersistedState("web-architect:industry", "");
  const [tone, setTone] = usePersistedState("web-architect:tone", "professional");
  const [tagline, setTagline] = usePersistedState("web-architect:tagline", "");
  const [primaryColor, setPrimaryColor] = usePersistedState("web-architect:primary-color", "#0F172A");
  const [accentColor, setAccentColor] = usePersistedState("web-architect:accent-color", "#F59E0B");
  const [fontFamily, setFontFamily] = usePersistedState("web-architect:font-family", "Inter");
  const [style, setStyle] = usePersistedState("web-architect:style", "minimal");
  const [selectedDevice, setSelectedDevice] = usePersistedState("web-architect:device", "desktop");

  const [html, setHtml] = usePersistedState<string | null>("web-architect:html", null);
  const [status, setStatus] = usePersistedState<Status>("web-architect:status", "idle");
  const [errorMessage, setErrorMessage] = usePersistedState<string | null>("web-architect:error", null);

  const canGenerate = brandName.trim().length > 0 && status !== "generating";

  const handleGenerate = async () => {
    if (!canGenerate) return;
    setStatus("generating");
    setErrorMessage(null);

    const brandProfile: BrandProfile = {
      brand_name: brandName.trim(),
      industry: industry.trim() || "technology",
      tone,
      tagline: tagline.trim() || undefined,
      primary_color: primaryColor,
      accent_color: accentColor,
      font_family: fontFamily,
    };

    try {
      const result = await requestWebsiteAgent({
        brand_profile: brandProfile,
        style,
      });
      if (!result.html) {
        throw new Error("Generation returned empty result");
      }
      setHtml(result.html);
      setStatus("done");
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : "Generation failed");
      setStatus("error");
    }
  };

  const deviceClass =
    selectedDevice === "desktop"
      ? "w-full"
      : selectedDevice === "tablet"
        ? "w-full max-w-3xl"
        : "w-full max-w-sm";

  return (
    <div className="flex h-full">
      <aside className="w-80 bg-[#181B24] border-r border-white/10 p-6 space-y-5 overflow-auto shrink-0">
        <div>
          <h2 className="text-white mb-1">Web Architect</h2>
          <p className="text-sm text-[#9CA3AF]">Generate a landing page from your brand</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm text-[#9CA3AF] mb-1.5 block">Brand name</label>
            <input
              type="text"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              placeholder="e.g. Lumen"
              className="w-full bg-[#0D0F14] border border-white/10 rounded px-3 py-2 text-white placeholder:text-[#6B7280] focus:outline-none focus:border-white/30 text-sm"
            />
          </div>

          <div>
            <label className="text-sm text-[#9CA3AF] mb-1.5 block">Industry</label>
            <input
              type="text"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              placeholder="e.g. fintech"
              className="w-full bg-[#0D0F14] border border-white/10 rounded px-3 py-2 text-white placeholder:text-[#6B7280] focus:outline-none focus:border-white/30 text-sm"
            />
          </div>

          <div>
            <label className="text-sm text-[#9CA3AF] mb-1.5 block">Tone</label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-[#0D0F14] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-white/30 text-sm"
            >
              {TONE_OPTIONS.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm text-[#9CA3AF] mb-1.5 block">Tagline</label>
            <input
              type="text"
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              placeholder="Optional"
              className="w-full bg-[#0D0F14] border border-white/10 rounded px-3 py-2 text-white placeholder:text-[#6B7280] focus:outline-none focus:border-white/30 text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-[#9CA3AF] mb-1.5 block">Primary color</label>
              <div className="flex gap-2">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-8 h-8 rounded border border-white/10 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="flex-1 bg-[#0D0F14] border border-white/10 rounded px-2 py-1.5 text-white text-xs focus:outline-none focus:border-white/30"
                />
              </div>
            </div>
            <div>
              <label className="text-sm text-[#9CA3AF] mb-1.5 block">Accent color</label>
              <div className="flex gap-2">
                <input
                  type="color"
                  value={accentColor}
                  onChange={(e) => setAccentColor(e.target.value)}
                  className="w-8 h-8 rounded border border-white/10 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={accentColor}
                  onChange={(e) => setAccentColor(e.target.value)}
                  className="flex-1 bg-[#0D0F14] border border-white/10 rounded px-2 py-1.5 text-white text-xs focus:outline-none focus:border-white/30"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="text-sm text-[#9CA3AF] mb-1.5 block">Font family</label>
            <select
              value={fontFamily}
              onChange={(e) => setFontFamily(e.target.value)}
              className="w-full bg-[#0D0F14] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-white/30 text-sm"
            >
              {FONT_OPTIONS.map((f) => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm text-[#9CA3AF] mb-2 block">Style</label>
            <div className="flex flex-wrap gap-2">
              {STYLE_OPTIONS.map((option) => (
                <button
                  key={option.id}
                  onClick={() => setStyle(option.id)}
                  className={`px-3 py-1.5 text-sm rounded border transition-colors ${
                    style === option.id
                      ? "border-white/40 bg-white/10 text-white"
                      : "border-white/10 text-[#9CA3AF] hover:border-white/20"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={!canGenerate}
          className="w-full py-3 rounded text-white flex items-center justify-center gap-2 bg-[#00356e] hover:bg-[#004080] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {status === "generating" ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4" />
              Generate Website
            </>
          )}
        </button>
      </aside>

      <div className="flex-1 flex flex-col">
        <div className="flex items-center justify-end gap-2 px-6 py-3 border-b border-white/10 bg-[#181B24]">
          {DEVICE_OPTIONS.map((option) => {
            const Icon = option.icon;
            const active = selectedDevice === option.id;
            return (
              <button
                key={option.id}
                onClick={() => setSelectedDevice(option.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs transition-colors ${
                  active
                    ? "bg-white/10 text-white border border-white/20"
                    : "text-[#9CA3AF] border border-transparent hover:text-white"
                }`}
              >
                <Icon className="w-4 h-4" />
                {option.label}
              </button>
            );
          })}
        </div>

        <div className="flex-1 p-4 flex items-stretch justify-center overflow-auto">
          <div
            className={`bg-[#181B24] border border-white/10 rounded transition-all overflow-hidden flex-1 ${deviceClass}`}
          >
            {status === "idle" && (
              <div className="h-full flex items-center justify-center text-[#6B7280] text-sm px-8 text-center">
                Fill in your brand details and click Generate to preview your website
              </div>
            )}

            {status === "generating" && (
              <div className="h-full flex flex-col items-center justify-center gap-3 text-[#9CA3AF]">
                <Loader2 className="w-8 h-8 animate-spin text-white" />
                <span className="text-sm">Generating your website...</span>
              </div>
            )}

            {status === "done" && html && (
              <iframe
                srcDoc={html}
                sandbox="allow-scripts"
                className="w-full h-full bg-white"
                title="Website preview"
              />
            )}

            {status === "error" && (
              <div className="h-full flex flex-col items-center justify-center gap-4 px-8">
                <div className="flex items-center gap-2 text-red-400">
                  <AlertCircle className="w-5 h-5" />
                  <span className="text-sm">{errorMessage || "Generation failed"}</span>
                </div>
                <button
                  onClick={handleGenerate}
                  className="px-4 py-2 text-sm rounded bg-[#00356e] text-white hover:bg-[#004080] transition-colors"
                >
                  Retry
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
