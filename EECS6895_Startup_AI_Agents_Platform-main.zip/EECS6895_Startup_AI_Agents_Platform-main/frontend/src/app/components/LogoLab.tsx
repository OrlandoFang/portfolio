import { Download, Sparkles } from "lucide-react";
import { useState } from "react";
import { extractBrandProfileFromDescription, requestLogoAgent } from "../api/agents";
import { usePersistedState } from "../hooks/usePersistedState";

export function LogoLab() {
  const [description, setDescription] = usePersistedState("logo-lab:description", "");
  /** Optional override; Logo Lab ignores Brand Hub — name comes from describe + LLM unless set here. */
  const [brandNameOverride, setBrandNameOverride] = usePersistedState("logo-lab:brand-name", "");
  const [showLogos, setShowLogos] = usePersistedState("logo-lab:show-logos", false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [apiSvg, setApiSvg] = usePersistedState<string | null>("logo-lab:api-svg", null);
  const [apiImageUrl, setApiImageUrl] = usePersistedState<string | null>("logo-lab:api-image-url", null);
  const [errorMessage, setErrorMessage] = usePersistedState<string | null>("logo-lab:error-message", null);

  const inferStyleFromDescription = (text: string): "minimal" | "bold" | "playful" | "corporate" => {
    const normalized = text.toLowerCase();
    if (normalized.includes("bold")) return "bold";
    if (normalized.includes("playful")) return "playful";
    if (normalized.includes("corporate")) return "corporate";
    return "minimal";
  };

  const handleDownload = async (url: string, filename: string) => {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      const objectUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = objectUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(objectUrl);
    } catch {
      // fallback: open in new tab
      window.open(url, "_blank");
    }
  };

  const handleGenerateLogos = async () => {
    if (isGenerating) return;

    const prompt = description.trim();
    if (!prompt) {
      setShowLogos(true);
      setErrorMessage("Enter a brand description so the Logo Agent can infer colours, tone, and name.");
      return;
    }

    const style = inferStyleFromDescription(prompt);
    setShowLogos(true);
    setIsGenerating(true);
    setErrorMessage(null);

    try {
      const profile = await extractBrandProfileFromDescription({
        brand_description: prompt,
        style,
      });
      const trimmedName = brandNameOverride.trim();
      const brand_profile = trimmedName ? { ...profile, brand_name: trimmedName } : profile;

      const response = await requestLogoAgent({
        brand_profile,
        style,
        mode: "both",
      });
      setApiSvg(response.svg || null);
      setApiImageUrl(response.image_url);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error";
      setErrorMessage(`Unable to generate logo: ${message}`);
      setApiSvg(null);
      setApiImageUrl(null);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-white mb-2">Logo Lab</h1>
        <p className="text-[#9CA3AF]">Generate a logo from your brand description</p>
      </div>

      <div className="bg-[#181B24] border border-white/10 p-6 rounded space-y-4">
        <label className="text-sm text-white block">Brand Description</label>
        <p className="text-xs text-[#6B7280]">
          Logo Lab uses only this page: your Brand Hub palette and Logo Lab drafts don’t cross over.
        </p>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Describe your brand identity, values, and target audience..."
          className="w-full h-32 px-4 py-3 bg-[#0D0F14] border border-white/10 rounded text-white placeholder:text-[#9CA3AF] resize-none focus:outline-none focus:ring-2 focus:ring-white/20"
        ></textarea>

        <label className="text-sm text-white block">Brand name (optional)</label>
        <input
          type="text"
          value={brandNameOverride}
          onChange={(e) => setBrandNameOverride(e.target.value)}
          placeholder="Overrides the inferred name — leave blank to use AI from description"
          className="w-full px-4 py-2 bg-[#0D0F14] border border-white/10 rounded text-white placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-white/20"
        />

        <div className="flex gap-3">
          <button
            onClick={handleGenerateLogos}
            disabled={isGenerating}
            className="flex-1 py-3 rounded text-white flex items-center justify-center gap-2 bg-[#00356e]"
          >
            <Sparkles className="w-4 h-4" />
            {isGenerating ? "Generating..." : "Generate Logo Concepts"}
          </button>
        </div>
      </div>

      {showLogos && (
        <div className="space-y-6">
          {errorMessage && (
            <div className="bg-[#181B24] border border-red-500/30 p-4 rounded">
              <p className="text-sm text-red-300">{errorMessage}</p>
            </div>
          )}
          {(apiSvg || apiImageUrl) && (
            <div className="bg-[#181B24] border border-white/10 rounded p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-white">Logo Agent Output</h3>
                <div className="flex gap-2">
                  {apiImageUrl && (
                    <button
                      onClick={() => handleDownload(apiImageUrl, "logo.png")}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded text-sm text-white bg-[#00356e] hover:brightness-110 transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      PNG
                    </button>
                  )}
                  {apiSvg && (
                    <button
                      onClick={() => {
                        const blob = new Blob([apiSvg], { type: "image/svg+xml" });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = "logo.svg";
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded text-sm text-white bg-[#0D0F14] border border-white/10 hover:bg-[#1F2230] transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      SVG
                    </button>
                  )}
                </div>
              </div>
              {apiImageUrl && (
                <div className="flex justify-center">
                  <img
                    src={apiImageUrl}
                    alt="Generated logo preview"
                    className="w-full max-w-md aspect-square object-contain bg-[#0D0F14] rounded border border-white/10 p-4"
                  />
                </div>
              )}
              {apiSvg && (
                <div className="bg-[#0D0F14] border border-white/10 rounded p-4 overflow-auto">
                  <p className="text-xs text-[#9CA3AF] mb-2">SVG Markup</p>
                  <pre className="text-xs text-white whitespace-pre-wrap break-all">{apiSvg}</pre>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
