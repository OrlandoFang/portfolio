import { Send, Sparkles } from "lucide-react";
import { useState } from "react";
import ReactMarkdown from "react-markdown";
import { defaultBrandProfile, requestMarketingAgent } from "../api/agents";
import { usePersistedState } from "../hooks/usePersistedState";
import { markdownComponents } from "./markdownComponents";

type ChatMessage = {
  role: "assistant" | "user";
  content: string;
  imageUrl?: string;
};

const defaultMessages: ChatMessage[] = [
  {
    role: "assistant",
    content: "Welcome to the Marketing Material Agent. Describe the campaign assets you need, and I'll generate context-aware designs synchronized with your brand identity.",
  },
];

export function MarketingChat() {
  const [input, setInput] = usePersistedState("marketing-chat:input", "");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = usePersistedState<ChatMessage[]>("marketing-chat:messages", defaultMessages);

  const handleSend = async () => {
    const userQuery = input.trim();
    if (!userQuery || isLoading) return;

    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userQuery }]);
    setIsLoading(true);

    try {
      const response = await requestMarketingAgent({
        brand_profile: defaultBrandProfile,
        user_query: userQuery,
      });

      const recommendationLine = response.platform_recommendations.platforms?.length
        ? `Recommended platforms: ${response.platform_recommendations.platforms.join(", ")}.`
        : "Platform recommendations unavailable.";
      const citationLine = response.citations.length
        ? `Sources: ${response.citations.join(", ")}.`
        : "No citations were returned.";

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `${response.strategy}\n\n${recommendationLine}\n${citationLine}`,
          imageUrl: response.ad_poster_url ?? undefined,
        },
      ]);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `I couldn't reach the marketing agent right now: ${errorMessage}`,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex h-full">
      <div className="flex-1 flex flex-col bg-[#0D0F14]">
        <div className="p-6 border-b border-white/10">
          <h2 className="text-white mb-1">Marketing Material Agent</h2>
          <p className="text-sm text-[#9CA3AF]">Consult design agent for campaign assets</p>
        </div>

        <div className="flex-1 overflow-auto p-6 space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-2xl rounded p-4 ${
                  message.role === "user"
                    ? "bg-white/10 text-white"
                    : "bg-[#181B24] border border-white/10 text-white"
                }`}
              >
                {message.role === "assistant" && (
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-[#9CA3AF]" />
                    <span className="text-sm text-[#9CA3AF]">AI Agent</span>
                  </div>
                )}
                <div className="text-sm leading-relaxed prose-invert">
                  <ReactMarkdown components={markdownComponents}>{message.content}</ReactMarkdown>
                </div>
                {message.imageUrl && (
                  <>
                    <hr className="my-4 border-white/10" />
                    <img
                      src={message.imageUrl}
                      alt="Generated ad poster"
                      className="w-full max-w-md rounded border border-white/10 bg-[#0D0F14]"
                    />
                  </>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 border-t border-white/10">
          <div className="flex gap-3">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Describe the marketing materials you need..."
              className="flex-1 px-4 py-3 bg-[#181B24] border border-white/10 rounded text-white placeholder:text-[#9CA3AF] resize-none focus:outline-none focus:ring-2 focus:ring-white/20"
              rows={3}
            ></textarea>
            <button
              onClick={handleSend}
              disabled={isLoading}
              className="px-6 rounded text-white flex items-center justify-center bg-[#00356e]"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          {isLoading && <p className="text-xs text-[#9CA3AF] mt-3">Marketing agent is generating your strategy...</p>}
        </div>
      </div>
    </div>
  );
}
