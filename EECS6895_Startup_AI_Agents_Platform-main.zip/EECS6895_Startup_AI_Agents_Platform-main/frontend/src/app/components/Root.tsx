import { Link, Outlet, useLocation } from "react-router";
import { Layers, Globe, Palette, MessageSquare, Settings } from "lucide-react";

export function Root() {
  const location = useLocation();

  const navItems = [
    { path: "/dashboard", label: "Brand Hub", icon: Layers },
    { path: "/dashboard/web-architect", label: "UI/UX Agent", icon: Globe },
    { path: "/dashboard/logo-lab", label: "Logo Agent", icon: Palette },
    { path: "/dashboard/marketing-chat", label: "Advertisement Agent", icon: MessageSquare },
    { path: "/dashboard/settings", label: "Settings", icon: Settings },
  ];

  const isActive = (path: string) => {
    if (path === "/dashboard") {
      return location.pathname === "/dashboard";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="flex h-screen bg-[#0D0F14]">
      <aside className="w-64 bg-[#181B24] border-r border-white/10 flex flex-col">
        <div className="p-6 border-b border-white/10">
          <div className="h-8 w-8 rounded mb-3" style={{ background: 'var(--prismatic-gradient)' }}></div>
          <h1 className="text-white tracking-tight">Brandforge AI</h1>
          <p className="text-[#9CA3AF] text-sm mt-1">Multi-Agent Design Platform</p>
        </div>

        <nav className="flex-1 p-4">
          <div className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);

              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded transition-colors ${
                    active
                      ? "bg-white/5 text-white"
                      : "text-[#9CA3AF] hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="">{item.label}</span>
                  {active && (
                    <div
                      className="ml-auto w-1 h-6 rounded-full bg-[#00356e]"
                    ></div>
                  )}
                </Link>
              );
            })}
          </div>
        </nav>

        <div className="p-4 border-t border-white/10">
          <div className="px-4 py-3 bg-[#2A2D38] rounded">
            <p className="text-xs text-[#9CA3AF]">Synchronization Active</p>
            <div className="flex items-center gap-2 mt-2">
              <div className="w-2 h-2 rounded-full bg-[#10B981]"></div>
              <p className="text-sm text-white">Brand Consistency Engine</p>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
