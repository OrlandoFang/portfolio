import { useState } from "react";
import { useNavigate } from "react-router";
import { Eye, EyeOff, ArrowRight } from "lucide-react";
import { usePersistedState } from "../hooks/usePersistedState";
import { loginWithApiKey } from "../api/projects";
import { ApiError } from "../api/client";

export function Login() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = usePersistedState<"signin" | "signup">("login:active-tab", "signin");
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = usePersistedState("login:remember", false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSignIn = async () => {
    setErrorMessage(null);
    const apiKey = password.trim() || "dev-key";
    setSubmitting(true);
    try {
      await loginWithApiKey(apiKey);
      navigate("/dashboard");
    } catch (err) {
      const message =
        err instanceof ApiError
          ? `Login failed (${err.status}): ${err.message}`
          : `Login failed: ${err instanceof Error ? err.message : String(err)}`;
      setErrorMessage(message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#0D0F14]">
      <div className="flex-1 flex items-center justify-center p-16">
        <div className="max-w-xl space-y-12">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded" style={{ background: 'var(--prismatic-gradient)' }}></div>
            <span className="text-white text-2xl tracking-tight">Brandforge AI</span>
          </div>

          <div>
            <h1 className="text-white text-5xl mb-2">WELCOME</h1>
            <h1
              className="text-5xl mb-6 text-[#00356e]"
            >
              BACK
            </h1>
            <p className="text-[#9CA3AF] text-lg">
              Continue shaping your brand.
            </p>
          </div>
        </div>
      </div>

      <div className="w-[500px] bg-[#181B24] border-l border-white/10 flex items-center justify-center p-12">
        <div className="w-full max-w-md space-y-8">
          <div className="flex gap-0 border border-white/10 rounded overflow-hidden">
            <button
              onClick={() => setActiveTab("signin")}
              className={`flex-1 py-3 transition-colors ${
                activeTab === "signin"
                  ? "bg-white text-[#0D0F14]"
                  : "bg-transparent text-[#9CA3AF] hover:bg-white/5"
              }`}
            >
              SIGN IN
            </button>
            <button
              onClick={() => setActiveTab("signup")}
              className={`flex-1 py-3 transition-colors ${
                activeTab === "signup"
                  ? "bg-white text-[#0D0F14]"
                  : "bg-transparent text-[#9CA3AF] hover:bg-white/5"
              }`}
            >
              SIGN UP
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <label className="text-xs text-[#9CA3AF] uppercase tracking-wider mb-2 block">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="w-full px-4 py-3 bg-transparent border border-white/10 rounded text-white placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-white/20"
              />
            </div>

            <div>
              <label className="text-xs text-[#9CA3AF] uppercase tracking-wider mb-2 block">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-transparent border border-white/10 rounded text-white placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-white/20"
                />
                <button
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#9CA3AF] hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="w-4 h-4"
                />
                <span className="text-sm text-[#9CA3AF]">Remember</span>
              </label>
              <button className="text-sm text-[#9CA3AF] hover:text-white">
                Forgot password?
              </button>
            </div>

            <button
              onClick={handleSignIn}
              disabled={submitting}
              className="w-full py-3 bg-white text-[#0D0F14] rounded flex items-center justify-center gap-2 hover:bg-white/90 disabled:opacity-60"
            >
              {submitting ? "SIGNING IN…" : "SIGN IN"}
              <ArrowRight className="w-4 h-4" />
            </button>

            {errorMessage && (
              <p className="text-sm text-red-400 mt-2" role="alert">
                {errorMessage}
              </p>
            )}
            <p className="text-xs text-[#9CA3AF] mt-2">
              Tip: leave the password empty (or use <code>dev-key</code>) for the local dev account.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
