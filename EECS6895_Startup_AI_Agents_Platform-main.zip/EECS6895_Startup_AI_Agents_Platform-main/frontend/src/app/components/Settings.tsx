import { useState } from "react";
import { useNavigate } from "react-router";
import { Power, Trash2, Lock, LogOut, AlertTriangle } from "lucide-react";
import { usePersistedState } from "../hooks/usePersistedState";

export function Settings() {
  const navigate = useNavigate();
  const [brandConsistencyActive, setBrandConsistencyActive] = usePersistedState("settings:brand-consistency-active", true);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleLogout = () => {
    navigate("/");
  };

  const handleRemoveHistory = () => {
    if (confirm("Are you sure you want to remove all user history? This action cannot be undone.")) {
      if (typeof window !== "undefined") {
        const prefixes = [
          "brand-hub:",
          "logo-lab:",
          "marketing-chat:",
          "web-architect:",
        ];
        const keysToRemove: string[] = [];
        for (let i = 0; i < window.localStorage.length; i += 1) {
          const key = window.localStorage.key(i);
          if (!key) continue;
          if (prefixes.some((prefix) => key.startsWith(prefix))) {
            keysToRemove.push(key);
          }
        }
        keysToRemove.forEach((key) => window.localStorage.removeItem(key));
        alert("All history and current inputs have been removed.");
        window.location.reload();
      }
    }
  };

  const handleChangePassword = () => {
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }
    if (newPassword.length < 8) {
      alert("Password must be at least 8 characters");
      return;
    }
    console.log("Password changed");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  const handleDeleteAccount = () => {
    if (confirm("Are you sure you want to delete your account? This action is permanent and cannot be undone.")) {
      console.log("Account deleted");
      navigate("/");
    }
  };

  return (
    <div className="p-8 space-y-8 max-w-4xl">
      <div>
        <h1 className="text-white mb-2">Settings</h1>
        <p className="text-[#9CA3AF]">Manage your account and preferences</p>
      </div>

      <div className="bg-[#181B24] border border-white/10 p-6 rounded space-y-6">
        <div>
          <h2 className="text-white mb-4">Brand Consistency Engine</h2>
          <div className="flex items-center justify-between p-4 bg-[#0D0F14] border border-white/10 rounded">
            <div className="flex items-center gap-3">
              <Power className="w-5 h-5 text-[#9CA3AF]" />
              <div>
                <p className="text-white">Engine Status</p>
                <p className="text-sm text-[#9CA3AF]">
                  {brandConsistencyActive ? "Active" : "Inactive"}
                </p>
              </div>
            </div>
            <button
              onClick={() => setBrandConsistencyActive(!brandConsistencyActive)}
              className={`px-4 py-2 rounded transition-colors ${
                brandConsistencyActive
                  ? "bg-[#00356e] text-white hover:bg-[#004080]"
                  : "bg-[#2A2D38] text-[#9CA3AF] hover:bg-white/5"
              }`}
            >
              {brandConsistencyActive ? "Deactivate" : "Activate"}
            </button>
          </div>
        </div>
      </div>

      <div className="bg-[#181B24] border border-white/10 p-6 rounded space-y-6">
        <div>
          <h2 className="text-white mb-4">Change Password</h2>
          <div className="space-y-4">
            <div>
              <label className="text-xs text-[#9CA3AF] uppercase tracking-wider mb-2 block">
                Current Password
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter current password"
                className="w-full px-4 py-3 bg-[#0D0F14] border border-white/10 rounded text-white placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-xs text-[#9CA3AF] uppercase tracking-wider mb-2 block">
                New Password
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new password"
                className="w-full px-4 py-3 bg-[#0D0F14] border border-white/10 rounded text-white placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-white/20"
              />
            </div>
            <div>
              <label className="text-xs text-[#9CA3AF] uppercase tracking-wider mb-2 block">
                Confirm New Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm new password"
                className="w-full px-4 py-3 bg-[#0D0F14] border border-white/10 rounded text-white placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-white/20"
              />
            </div>
            <button
              onClick={handleChangePassword}
              className="px-6 py-2 bg-[#00356e] rounded text-white hover:bg-[#004080] transition-colors flex items-center gap-2"
            >
              <Lock className="w-4 h-4" />
              Update Password
            </button>
          </div>
        </div>
      </div>

      <div className="bg-[#181B24] border border-white/10 p-6 rounded space-y-6">
        <div>
          <h2 className="text-white mb-4">Data Management</h2>
          <div className="flex items-center justify-between p-4 bg-[#0D0F14] border border-white/10 rounded">
            <div className="flex items-center gap-3">
              <Trash2 className="w-5 h-5 text-[#9CA3AF]" />
              <div>
                <p className="text-white">Remove All History</p>
                <p className="text-sm text-[#9CA3AF]">Delete all generated assets and activity</p>
              </div>
            </div>
            <button
              onClick={handleRemoveHistory}
              className="px-4 py-2 bg-[#2A2D38] border border-white/10 rounded text-white hover:bg-white/5 transition-colors"
            >
              Remove
            </button>
          </div>
        </div>
      </div>

      <div className="bg-[#181B24] border border-white/10 p-6 rounded space-y-6">
        <div>
          <h2 className="text-white mb-4">Account Actions</h2>
          <div className="space-y-3">
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-between p-4 bg-[#0D0F14] border border-white/10 rounded text-white hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <LogOut className="w-5 h-5 text-[#9CA3AF]" />
                <span>Log Out</span>
              </div>
            </button>

            <button
              onClick={handleDeleteAccount}
              className="flex items-center gap-2 text-sm text-[#EF4444] hover:text-[#DC2626] transition-colors"
            >
              <AlertTriangle className="w-4 h-4" />
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
