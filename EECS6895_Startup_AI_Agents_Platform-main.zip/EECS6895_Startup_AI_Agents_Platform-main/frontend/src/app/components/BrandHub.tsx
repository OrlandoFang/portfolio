import { Sparkles, Palette, Type, Image, Check, Plus, Loader2, Download } from "lucide-react";
import { useState } from "react";
import ReactMarkdown from "react-markdown";
import { usePersistedState } from "../hooks/usePersistedState";
import {
  createProject,
  waitForProject,
  type ProjectResult,
} from "../api/projects";
import { ApiError } from "../api/client";
import { BRAND_HUB_THEME_OPTIONS, resolveBrandHubThemeColors } from "../brandHubThemes";
import { markdownComponents } from "./markdownComponents";

const STYLE_MAP: Record<string, string> = {
  Simple: "minimal",
  Neutral: "corporate",
  Complex: "bold",
};
const STYLE_LABEL_MAP: Record<string, string> = {
  minimal: "Simple",
  corporate: "Neutral",
  bold: "Complex",
  playful: "Complex",
};

type OutputKind = "website" | "logo" | "marketing";

export function BrandHub() {
  const [selectedPalette, setSelectedPalette] = usePersistedState("brand-hub:selected-palette", "Choose your own palette");
  const [selectedTone, setSelectedTone] = usePersistedState("brand-hub:selected-tone", "Neutral");
  const [customColors, setCustomColors] = usePersistedState<string[]>("brand-hub:custom-colors", []);
  const [showColorInput, setShowColorInput] = useState(false);
  const [newColor, setNewColor] = useState("#000000");

  const [description, setDescription] = usePersistedState("brand-hub:description", "");
  const [outputs, setOutputs] = usePersistedState<OutputKind[]>(
    "brand-hub:outputs",
    ["logo", "marketing"],
  );
  const [generating, setGenerating] = useState(false);
  const [project, setProject] = useState<ProjectResult | null>(null);
  const [projectError, setProjectError] = useState<string | null>(null);
  const [logoTab, setLogoTab] = useState<"svg" | "png">("svg");

  const toggleOutput = (kind: OutputKind) => {
    setOutputs((prev) =>
      prev.includes(kind) ? prev.filter((k) => k !== kind) : [...prev, kind],
    );
  };

  const handleGenerate = async () => {
    setProjectError(null);
    if (!description.trim()) {
      setProjectError("Please enter a brand description first.");
      return;
    }
    if (outputs.length === 0) {
      setProjectError("Pick at least one output type.");
      return;
    }
    setGenerating(true);
    try {
      const style = STYLE_MAP[selectedTone] ?? "corporate";
      const theme_colors = resolveBrandHubThemeColors(selectedPalette, customColors);
      const initial = await createProject({
        brand_description: description.trim(),
        style,
        outputs,
        ...(theme_colors?.length ? { theme_colors } : {}),
      });
      setProject(initial);
      const final = await waitForProject(initial.project_id, {
        intervalMs: 2000,
        timeoutMs: 180_000,
        onUpdate: setProject,
      });
      setProject(final);
    } catch (err) {
      const message =
        err instanceof ApiError
          ? `Generation failed (${err.status}): ${err.message}`
          : `Generation failed: ${err instanceof Error ? err.message : String(err)}`;
      setProjectError(message);
    } finally {
      setGenerating(false);
    }
  };

  const handleAddColor = () => {
    if (customColors.length < 6) {
      setCustomColors([...customColors, newColor]);
      setNewColor("#000000");
      setShowColorInput(false);
    }
  };

  const toneOptions = ["Simple", "Neutral", "Complex"];

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-white mb-2">Brand Hub</h1>
        <p className="text-[#9CA3AF]">Where you choose the theme and style you like for your brand.</p>
      </div>

      

      <div className="bg-[#181B24] border border-white/10 p-6 rounded">
        <h2 className="text-white mb-4">Brand Themes</h2>
        <div className="grid grid-cols-2 gap-4">
          {BRAND_HUB_THEME_OPTIONS.map((theme) => (
            <button
              key={theme.name}
              onClick={() => setSelectedPalette(theme.name)}
              className={`p-4 bg-[#0D0F14] border rounded transition-all text-left ${
                selectedPalette === theme.name
                  ? "border-white/40 ring-2 ring-white/20"
                  : "border-white/10 hover:border-white/20"
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-[#9CA3AF]">{theme.name}</p>
                {selectedPalette === theme.name && (
                  <Check className="w-4 h-4 text-white" />
                )}
              </div>
              <div className="flex gap-2">
                {theme.name === "Choose your own palette" ? (
                  <>
                    {customColors.map((color, idx) => (
                      <div
                        key={idx}
                        className="w-8 h-8 rounded border border-white/10"
                        style={{ backgroundColor: color }}
                      ></div>
                    ))}
                    {customColors.length < 6 && (
                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowColorInput(!showColorInput);
                        }}
                        className="w-8 h-8 rounded border border-white/10 bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer"
                      >
                        <Plus className="w-4 h-4 text-white" />
                      </div>
                    )}
                    {showColorInput && (
                      <div className="flex gap-2 ml-2" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="color"
                          value={newColor}
                          onChange={(e) => setNewColor(e.target.value)}
                          className="w-8 h-8 rounded border border-white/10 cursor-pointer"
                        />
                        <div
                          onClick={handleAddColor}
                          className="px-3 py-1 bg-[#00356e] text-white text-xs rounded hover:bg-[#004080] cursor-pointer"
                        >
                          Add
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  theme.colors.map((color) => (
                    <div
                      key={color}
                      className="w-8 h-8 rounded border border-white/10"
                      style={{ backgroundColor: color }}
                    ></div>
                  ))
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-[#181B24] border border-white/10 p-6 rounded">
        <h2 className="text-white mb-4">Style Settings</h2>
        <div className="grid grid-cols-3 gap-4">
          {toneOptions.map((tone) => (
            <button
              key={tone}
              onClick={() => setSelectedTone(tone)}
              className={`p-4 bg-[#0D0F14] border rounded transition-all ${
                selectedTone === tone
                  ? "border-white/40 ring-2 ring-white/20 text-white"
                  : "border-white/10 hover:border-white/20 text-[#9CA3AF]"
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                {selectedTone === tone && <Check className="w-4 h-4" />}
                <span>{tone}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-[#181B24] border border-white/10 p-6 rounded space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-white">Generate Brand Project</h2>
          {project?.status && (
            <span
              className={`text-xs px-2 py-1 rounded border ${
                project.status === "done"
                  ? "border-emerald-400/40 text-emerald-300"
                  : project.status === "error"
                    ? "border-red-400/40 text-red-300"
                    : "border-white/20 text-[#9CA3AF]"
              }`}
            >
              status: {project.status}
            </span>
          )}
        </div>

        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Describe your brand (e.g. 'A calm, eco-friendly tea company targeting young professionals')."
          rows={4}
          className="w-full bg-[#0D0F14] border border-white/10 rounded p-3 text-white placeholder:text-[#6B7280] focus:outline-none focus:border-white/30"
        />

        <div className="flex flex-wrap gap-3">
          {(["logo", "marketing", "website"] as OutputKind[]).map((kind) => {
            const active = outputs.includes(kind);
            return (
              <button
                key={kind}
                type="button"
                onClick={() => toggleOutput(kind)}
                className={`px-3 py-1.5 text-sm rounded border transition-colors ${
                  active
                    ? "border-white/40 bg-white/10 text-white"
                    : "border-white/10 text-[#9CA3AF] hover:border-white/20"
                }`}
              >
                {active ? "✓ " : ""}
                {kind}
              </button>
            );
          })}
        </div>

        <button
          onClick={handleGenerate}
          disabled={generating}
          className="px-4 py-2 bg-white text-[#0D0F14] rounded hover:bg-white/90 disabled:opacity-60 flex items-center gap-2"
        >
          {generating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Generating…
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              Generate
            </>
          )}
        </button>

        {projectError && (
          <p className="text-sm text-red-400" role="alert">
            {projectError}
          </p>
        )}

        {project && (
          <div className="mt-4 space-y-4 text-sm">
            <div className="text-[#9CA3AF]">
              project_id: <code className="text-white">{project.project_id}</code>
            </div>

            {project.brand_profile && (
              <div className="p-3 bg-[#0D0F14] border border-white/10 rounded">
                <p className="text-white mb-2">Brand profile</p>
                <ul className="space-y-1 text-[#9CA3AF]">
                  <li>Name: <span className="text-white">{project.brand_profile.brand_name}</span></li>
                  <li>
                    Style:{" "}
                    <span className="text-white">
                      {STYLE_LABEL_MAP[(project.style ?? "").toLowerCase()] ?? selectedTone}
                    </span>
                  </li>
                  <li>Industry: <span className="text-white">{project.brand_profile.industry}</span></li>
                  <li>
                    Theme colors:
                    <span className="inline-flex flex-wrap items-center gap-2 ml-2">
                      {(project.theme_colors?.length ? project.theme_colors : [project.brand_profile.primary_color, project.brand_profile.accent_color]).map((color) => (
                        <span key={color} className="inline-flex items-center gap-1">
                          <span
                            className="inline-block w-4 h-4 rounded border border-white/20"
                            style={{ backgroundColor: color }}
                          />
                          <span className="text-white">{color}</span>
                        </span>
                      ))}
                    </span>
                  </li>
                  {project.brand_profile.tagline && (
                    <li>Tagline: <span className="text-white italic">“{project.brand_profile.tagline}”</span></li>
                  )}
                </ul>
              </div>
            )}

            {(project.logo_svg || project.logo_image_url) && (
              <div className="p-3 bg-[#0D0F14] border border-white/10 rounded">
                <div className="flex items-center gap-3 mb-3">
                  <p className="text-white">Logo</p>
                  {project.logo_svg && project.logo_image_url && (
                    <div className="flex bg-[#181B24] border border-white/10 rounded overflow-hidden">
                      <button
                        onClick={() => setLogoTab("svg")}
                        className={`px-3 py-1 text-xs transition-colors ${
                          logoTab === "svg" ? "bg-white/10 text-white" : "text-[#9CA3AF] hover:text-white"
                        }`}
                      >
                        SVG
                      </button>
                      <button
                        onClick={() => setLogoTab("png")}
                        className={`px-3 py-1 text-xs transition-colors ${
                          logoTab === "png" ? "bg-white/10 text-white" : "text-[#9CA3AF] hover:text-white"
                        }`}
                      >
                        PNG
                      </button>
                    </div>
                  )}
                  <div className="flex gap-2 ml-auto">
                    {project.logo_svg && (
                      <button
                        onClick={() => {
                          const blob = new Blob([project.logo_svg!], { type: "image/svg+xml" });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement("a");
                          a.href = url;
                          a.download = "logo.svg";
                          document.body.appendChild(a);
                          a.click();
                          document.body.removeChild(a);
                          URL.revokeObjectURL(url);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded text-sm text-white bg-[#0D0F14] border border-white/10 hover:bg-[#1F2230] transition"
                      >
                        <Download className="w-3.5 h-3.5" />
                        SVG
                      </button>
                    )}
                    {project.logo_image_url && (
                      <button
                        onClick={async () => {
                          try {
                            const res = await fetch(project.logo_image_url!);
                            const blob = await res.blob();
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement("a");
                            a.href = url;
                            a.download = "logo.png";
                            document.body.appendChild(a);
                            a.click();
                            document.body.removeChild(a);
                            URL.revokeObjectURL(url);
                          } catch {
                            window.open(project.logo_image_url!, "_blank");
                          }
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded text-sm text-white bg-[#00356e] hover:brightness-110 transition"
                      >
                        <Download className="w-3.5 h-3.5" />
                        PNG
                      </button>
                    )}
                  </div>
                </div>
                <div className="flex justify-center">
                  {(logoTab === "svg" || !project.logo_image_url) && project.logo_svg ? (
                    <div
                      className="w-full max-w-md aspect-square bg-white rounded flex items-center justify-center overflow-hidden"
                      dangerouslySetInnerHTML={{ __html: project.logo_svg }}
                    />
                  ) : (
                    <img
                      src={project.logo_image_url!}
                      alt="Generated logo"
                      className="w-full max-w-md aspect-square object-contain bg-[#0D0F14] rounded border border-white/10 p-4"
                    />
                  )}
                </div>
              </div>
            )}

            {project.marketing_strategy && (
              <div className="p-3 bg-[#0D0F14] border border-white/10 rounded">
                <p className="text-white mb-2">Marketing strategy</p>
                <div className="text-sm leading-relaxed text-[#9CA3AF]">
                  <ReactMarkdown components={markdownComponents}>
                    {project.marketing_strategy}
                  </ReactMarkdown>
                </div>
              </div>
            )}

            {project.website_html && (
              <div className="p-3 bg-[#0D0F14] border border-white/10 rounded">
                <p className="text-white mb-2">Website</p>
                <iframe
                  srcDoc={project.website_html}
                  className="w-full h-[550px] rounded border border-white/10 bg-white"
                  sandbox="allow-scripts"
                  title="Website preview"
                />
              </div>
            )}
          </div>
        )}
      </div>

    </div>
  );
}
