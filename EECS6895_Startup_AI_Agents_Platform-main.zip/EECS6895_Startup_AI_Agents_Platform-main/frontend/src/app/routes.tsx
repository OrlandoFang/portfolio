import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { BrandHub } from "./components/BrandHub";
import { WebArchitect } from "./components/WebArchitect";
import { LogoLab } from "./components/LogoLab";
import { MarketingChat } from "./components/MarketingChat";
import { Settings } from "./components/Settings";
import { Login } from "./components/Login";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/dashboard",
    Component: Root,
    children: [
      { index: true, Component: BrandHub },
      { path: "web-architect", Component: WebArchitect },
      { path: "logo-lab", Component: LogoLab },
      { path: "marketing-chat", Component: MarketingChat },
      { path: "settings", Component: Settings },
    ],
  },
]);
