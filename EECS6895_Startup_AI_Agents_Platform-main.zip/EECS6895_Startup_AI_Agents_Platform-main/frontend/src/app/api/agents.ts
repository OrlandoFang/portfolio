const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "") || "http://localhost:8000";

type BrandProfile = {
  brand_name: string;
  primary_color: string;
  accent_color: string;
  font_family: string;
  tone: string;
  industry: string;
  tagline?: string;
};

type MarketingRequest = {
  brand_profile: BrandProfile;
  user_query: string;
};

type LogoRequest = {
  brand_profile: BrandProfile;
  style: string;
  mode?: "svg" | "dalle" | "both";
};

export type MarketingResponse = {
  strategy: string;
  platform_recommendations: {
    platforms?: string[];
    audience?: string[];
    region?: string;
    industry_query?: string;
  };
  citations: string[];
  ad_poster_url?: string | null;
};

export type LogoResponse = {
  svg: string;
  image_url: string | null;
};

export const defaultBrandProfile: BrandProfile = {
  brand_name: "Brandforge",
  primary_color: "#00356e",
  accent_color: "#FFFFFF",
  font_family: "Inter",
  tone: "professional",
  industry: "creative technology",
  tagline: "Build your brand, faster",
};

async function requestJson<TResponse>(path: string, body: unknown): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const fallbackMessage = `Request failed with status ${response.status}`;
    try {
      const data = await response.json();
      const detail = typeof data?.detail === "string" ? data.detail : fallbackMessage;
      throw new Error(detail);
    } catch {
      throw new Error(fallbackMessage);
    }
  }

  return (await response.json()) as TResponse;
}

export function requestMarketingAgent(payload: MarketingRequest): Promise<MarketingResponse> {
  return requestJson<MarketingResponse>("/agents/marketing", payload);
}

type BrandExtractRequest = {
  brand_description: string;
  style: string;
};

type BrandExtractResponse = {
  brand_profile: BrandProfile;
};

/** Build a BrandProfile from free text (Logo Lab); independent of Brand Hub palette. */
export function extractBrandProfileFromDescription(body: BrandExtractRequest): Promise<BrandProfile> {
  return requestJson<BrandExtractResponse>("/agents/brand/profile", body).then((r) => r.brand_profile);
}

export function requestLogoAgent(payload: LogoRequest): Promise<LogoResponse> {
  return requestJson<LogoResponse>("/agents/logo", payload);
}

type WebsiteRequest = {
  brand_profile: BrandProfile;
  style: string;
  theme_colors?: string[] | null;
};

type WebsiteResponse = {
  html: string;
};

export function requestWebsiteAgent(payload: WebsiteRequest): Promise<WebsiteResponse> {
  return requestJson<WebsiteResponse>("/agents/website", payload);
}
