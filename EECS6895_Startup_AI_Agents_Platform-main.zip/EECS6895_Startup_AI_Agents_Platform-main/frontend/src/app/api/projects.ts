// Wrapper over the Tianrui-owned REST API:
//   POST  /api/auth/token
//   POST  /api/projects
//   GET   /api/projects/{id}
//   GET   /api/projects

import { clearToken, getJson, postJson, setToken } from "./client";

// ── Types (shared contracts) ────────────────────────────────────────────
export type BrandProfile = {
  brand_name: string;
  primary_color: string;
  accent_color: string;
  font_family: string;
  tone: string;
  industry: string;
  tagline?: string | null;
};

export type ProjectStatus = "pending" | "running" | "done" | "error";

export type ProjectResult = {
  project_id: string;
  status: ProjectStatus;
  style: string | null;
  theme_colors: string[] | null;
  brand_profile: BrandProfile | null;
  website_html: string | null;
  logo_svg: string | null;
  logo_image_url: string | null;
  marketing_strategy: string | null;
  platform_recommendations: Record<string, unknown> | null;
};

export type CreateProjectRequest = {
  brand_description: string;
  style: "minimal" | "bold" | "playful" | "corporate" | string;
  outputs: Array<"website" | "logo" | "marketing">;
  /** Brand Hub palette: ordered hex swatches — backend maps [0]=primary, [1]=accent. */
  theme_colors?: string[];
};

type TokenResponse = {
  access_token: string;
  token_type: string;
  expires_in: number;
};

// ── Auth ────────────────────────────────────────────────────────────────
export async function loginWithApiKey(apiKey: string): Promise<TokenResponse> {
  const res = await postJson<TokenResponse>("/api/auth/token", { api_key: apiKey });
  setToken(res.access_token);
  return res;
}

export function logout(): void {
  clearToken();
}

// ── Projects ────────────────────────────────────────────────────────────
export function createProject(req: CreateProjectRequest): Promise<ProjectResult> {
  return postJson<ProjectResult>("/api/projects", req);
}

export function getProject(projectId: string): Promise<ProjectResult> {
  return getJson<ProjectResult>(`/api/projects/${encodeURIComponent(projectId)}`);
}

export function listProjects(): Promise<ProjectResult[]> {
  return getJson<ProjectResult[]>("/api/projects");
}

// ── Convenience: poll until done / error / timeout ──────────────────────
export async function waitForProject(
  projectId: string,
  {
    intervalMs = 2000,
    timeoutMs = 120_000,
    onUpdate,
    signal,
  }: {
    intervalMs?: number;
    timeoutMs?: number;
    onUpdate?: (result: ProjectResult) => void;
    signal?: AbortSignal;
  } = {}
): Promise<ProjectResult> {
  const started = Date.now();
  while (true) {
    if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
    const result = await getProject(projectId);
    onUpdate?.(result);
    if (result.status === "done" || result.status === "error") return result;
    if (Date.now() - started > timeoutMs) {
      throw new Error(`Timed out after ${timeoutMs} ms (last status: ${result.status})`);
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
}
