// Shared HTTP client for all Brandforge backend calls.
//
// - Reads the backend base URL from VITE_API_BASE_URL (defaults to localhost:8000).
// - Persists the JWT returned by POST /api/auth/token in localStorage under
//   `brandforge:auth-token` and automatically attaches it as
//   `Authorization: Bearer <token>` to every request.
// - Exposes a tiny ApiError type so callers can distinguish HTTP errors from
//   network errors and read `status` + `detail`.

export const API_BASE_URL =
  (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "") ||
  "http://localhost:8000";

const TOKEN_STORAGE_KEY = "brandforge:auth-token";

// ── Token helpers ────────────────────────────────────────────────────────
export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_STORAGE_KEY);
}

export function setToken(token: string): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(TOKEN_STORAGE_KEY, token);
}

export function clearToken(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(TOKEN_STORAGE_KEY);
}

export function isAuthenticated(): boolean {
  return !!getToken();
}

// ── Errors ──────────────────────────────────────────────────────────────
export class ApiError extends Error {
  status: number;
  detail: unknown;
  constructor(message: string, status: number, detail?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.detail = detail;
  }
}

// ── Core fetch ──────────────────────────────────────────────────────────
export async function apiFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers || {});
  if (!headers.has("Content-Type") && init.body) {
    headers.set("Content-Type", "application/json");
  }
  const token = getToken();
  if (token && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers });

  if (!response.ok) {
    let detail: unknown = undefined;
    let message = `Request failed with status ${response.status}`;
    try {
      const data = await response.json();
      detail = data;
      if (typeof data?.detail === "string") message = data.detail;
      else if (typeof data?.error === "string") message = data.error;
    } catch {
      // response was not JSON
    }
    throw new ApiError(message, response.status, detail);
  }

  if (response.status === 204) return undefined as unknown as T;
  return (await response.json()) as T;
}

export function postJson<T>(path: string, body: unknown): Promise<T> {
  return apiFetch<T>(path, { method: "POST", body: JSON.stringify(body) });
}

export function getJson<T>(path: string): Promise<T> {
  return apiFetch<T>(path, { method: "GET" });
}
