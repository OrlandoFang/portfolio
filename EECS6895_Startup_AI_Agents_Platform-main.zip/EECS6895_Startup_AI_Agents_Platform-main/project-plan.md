# Creative AI Agent — Project Plan & Task Division

**Team:** Tianrui Fang, Hao Chen, Tianyu Zhan
**Course:** EECS E6895 Advanced Big Data & AI
**Stack:** Python + FastAPI · React + Vite · MongoDB · OpenAI API

---

## Project Overview

An all-in-one AI-powered creative platform for early-stage startups. Users input their brand description and style preferences; the system auto-generates three artifacts in parallel:

| Artifact | Description |
|---|---|
| Website UI/UX | Full responsive HTML/Tailwind landing page code |
| Logo | SVG vector logo (LLM-generated) + image logo (DALL-E 3) |
| Marketing Materials | Ad strategy, platform recommendations, ad copy (with RAG) |

---

## System Architecture

```
Frontend (React + Vite)
    │
    ↓  POST /api/projects
Backend (FastAPI)
    │  auth + job creation
    ↓
Brand Agent  ──→  BrandProfile
    │              { primary_color, accent_color,
    │                font_family, tone, industry }
    ↓
AI Gateway / Router
    │  asyncio.gather (parallel dispatch)
    ├──────────────────┬──────────────────┐
    ↓                  ↓                  ↓
UI/Web Agent      Logo Agent       Marketing Agent
  HTML/Tailwind   SVG + DALL-E     Strategy + RAG
    │                  │                  │
    └──────────────────┴──────────────────┘
                       ↓
                   MongoDB
```

---

## Project Structure

```
creative-ai-agent/
├── backend/
│   ├── main.py                    # FastAPI app entry
│   ├── config.py                  # Pydantic Settings (.env)
│   ├── api/
│   │   ├── auth.py                # POST /api/auth/token
│   │   ├── projects.py            # CRUD /api/projects
│   │   └── agents.py              # Internal agent passthrough
│   ├── models/
│   │   ├── brand_profile.py       # BrandProfile Pydantic model
│   │   ├── project.py             # Project + GenerationJob
│   │   └── job.py
│   ├── agents/
│   │   ├── brand/                 # Brand Agent
│   │   ├── gateway/               # AI Router (fan-out)
│   │   ├── ui_web/                # UI/Web Agent
│   │   ├── logo/                  # Logo Agent
│   │   └── marketing/             # Migrated from Midterm Project
│   └── db/
│       └── client.py              # Motor async MongoDB client
├── frontend/
│   └── src/
│       ├── pages/
│       │   ├── BrandForm.jsx      # Step 1: brand onboarding
│       │   └── Results.jsx        # Step 3: tabbed results
│       ├── components/
│       │   ├── WebPreview.jsx
│       │   ├── LogoPreview.jsx
│       │   └── MarketingView.jsx
│       └── api/
│           └── client.js          # Fetch wrapper
└── tests/
```

---

## Task Division

### Member 1 — Tianrui Fang
**Backend Infrastructure + Brand Agent + AI Gateway**

#### FastAPI App Scaffold
- `main.py`: app factory, CORS, exception handlers, router registration
- `config.py`: Pydantic `Settings` loading from `.env`
- Auth middleware

#### MongoDB Setup (`backend/db/`)
- Motor async driver connection
- Collections: `users`, `projects`, `jobs`
- Indexes on `project_id`, `user_id`

#### Data Models (`backend/models/`)
- `BrandProfile`: primary_color, accent_color, font_family, tone, industry, tagline
- `Project`: id, user_id, brand_profile, status, created_at, results
- `GenerationJob`: project_id, agent_type, status, output

#### REST API Endpoints
| Endpoint | Method | Description |
|---|---|---|
| `/api/auth/token` | POST | API key / JWT auth |
| `/api/projects` | POST | Create project, trigger pipeline |
| `/api/projects/{id}` | GET | Poll job status + results |
| `/api/projects` | GET | List user projects |

#### Brand Agent (`backend/agents/brand/`)
- Input: brand description text + style preferences
- LLM call (JSON mode) → structured `BrandProfile`
- Extracts: hex colors, font family, tone, industry category

#### AI Gateway / Router (`backend/agents/gateway/`)
- Receives `BrandProfile` + requested output types
- Dispatches sub-agents in **parallel** via `asyncio.gather`
- Aggregates results → saves to MongoDB → updates job status
- Partial failure OK: one failed agent doesn't block the others

---

### Member 2 — Hao Chen
**Marketing Agent (Midterm Migration) + Logo Agent**

#### Marketing Agent (`backend/agents/marketing/`)

Migration from Midterm Project (Flask → FastAPI). Keep the core pipeline intact.

**Source files to port from Midterm:**
```
src/marketing_agent/tools/platform_chooser.py  →  agents/marketing/tools/
src/marketing_agent/rag/pipeline.py            →  agents/marketing/rag/
agents/router.py                               →  agents/marketing/router.py
agents/synthesizer.py                          →  agents/marketing/synthesizer.py
llm/__init__.py                                →  agents/marketing/llm/
data/benchmarks/*.csv                          →  data/benchmarks/
data/corpus/ad_policy_corpus.jsonl             →  data/corpus/
```

**Changes from midterm:**
- Replace Flask `@app.route` → FastAPI `APIRouter`
- Make LLM init async-safe (lazy singleton preserved)
- Inject `BrandProfile` into Synthesizer prompt (brand tone + industry context)
- Remove Flask static file serving

**Endpoint:** `POST /agents/marketing` (internal, called by Gateway)
```
Input:  { brand_profile: BrandProfile, user_query: str }
Output: { strategy: str, platform_recommendations: dict, citations: list }
```

#### Logo Agent (`backend/agents/logo/`)

| Mode | Approach | Output |
|---|---|---|
| Primary | LLM prompt → SVG code | SVG string (vector, scalable) |
| Secondary | DALL-E 3 API | Image URL / base64 |

- Brand name + `BrandProfile` → prompt → SVG generation + validation/sanitization
- DALL-E prompt constructed from brand tone, colors, industry
- Both outputs returned together

**Endpoint:** `POST /agents/logo` (internal)
```
Input:  { brand_profile: BrandProfile, style: str }
Output: { svg: str, image_url: str | null }
```

---

### Member 3 — Tianyu Zhan
**UI/Web Agent + Frontend**

#### UI/Web Agent (`backend/agents/ui_web/`)

Two-step LLM generation:
1. **Plan**: LLM outputs JSON list of page sections + content outline
2. **Generate**: LLM generates full HTML + Tailwind CSS per section → assembled into complete page

**Endpoint:** `POST /agents/ui` (internal)
```
Input:  { brand_profile: BrandProfile, sections: list[str] }
Output: { html: str, sections: list[str] }
```

Sections include: `nav`, `hero`, `features`, `cta`, `footer`

#### Frontend (`frontend/`) — React 18 + Vite + Tailwind CSS

**Step 1 — Brand Onboarding Form** (`BrandForm.jsx`)
- Brand name + description (textarea)
- Industry (dropdown)
- Style preference: Minimal / Bold / Playful / Corporate
- Output type checkboxes: Website / Logo / Marketing Materials

**Step 2 — Generation in Progress**
- Animated loading state per agent
- Poll `GET /api/projects/{id}` every 2s

**Step 3 — Results** (`Results.jsx`)

| Tab | Content |
|---|---|
| Website | `<iframe>` preview of generated HTML + code copy button |
| Logo | SVG render + DALL-E image side-by-side + download |
| Marketing | Markdown-rendered strategy + platform recommendation table |

---

## Shared Responsibilities (All Members)

- **Week 1**: API contract meeting — finalize all Pydantic request/response schemas before coding
- **`.env.example`**: document all required env vars (`OPENAI_API_KEY`, `MONGODB_URI`, etc.)
- **Integration test**: end-to-end test with a real brand description
- **README**: local setup instructions

---

## API Contract (Shared Schema — define early)

```python
# BrandProfile — source of truth, shared by all agents
class BrandProfile(BaseModel):
    brand_name: str
    primary_color: str        # hex, e.g. "#2D6BE4"
    accent_color: str         # hex
    font_family: str          # e.g. "Inter", "Playfair Display"
    tone: str                 # e.g. "professional", "playful", "bold"
    industry: str             # e.g. "fintech", "health", "e-commerce"
    tagline: str | None

# Project creation request
class CreateProjectRequest(BaseModel):
    brand_description: str
    style: str                # "minimal" | "bold" | "playful" | "corporate"
    outputs: list[str]        # ["website", "logo", "marketing"]

# Project result response
class ProjectResult(BaseModel):
    project_id: str
    status: str               # "pending" | "running" | "done" | "error"
    brand_profile: BrandProfile | None
    website_html: str | None
    logo_svg: str | None
    logo_image_url: str | None
    marketing_strategy: str | None
    platform_recommendations: dict | None
```

---

## Dependencies

**Backend additions to midterm `requirements.txt`:**
```
fastapi>=0.111.0
uvicorn[standard]>=0.30.0
motor>=3.4.0              # async MongoDB driver
pydantic-settings>=2.0    # .env config
python-jose[cryptography] # JWT auth
# Preserved from midterm:
# langchain, faiss-cpu, sentence-transformers, openai, etc.
```

**Frontend `package.json`:**
```json
{
  "react": "^18.2.0",
  "vite": "^5.0.0",
  "tailwindcss": "^3.4.0",
  "react-markdown": "^10.0.0",
  "remark-gfm": "^4.0.0"
}
```

---

## Evaluation Metrics (from Proposal)

| Metric | Target |
|---|---|
| UI Completeness | Generated HTML contains nav + hero + CTA + footer |
| Generation Speed | All 3 agents complete in < 30 seconds |
| Visual Satisfaction | Team rates output quality (1–5 scale) |
| User Rating | External feedback from 3+ test users |
